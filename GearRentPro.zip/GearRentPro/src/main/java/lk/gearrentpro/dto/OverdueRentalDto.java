/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dto;

import java.util.Date;

/**
 *
 * @author asus
 */
public class OverdueRentalDto {
    private int reservationId;
    private String reservationCode;
    private int equipmentId;
    private int customerId;
    private int branchId;
    private Date endDate;
    private int overdueDays;
    private double lateFee;

    public OverdueRentalDto() {
    }

    public OverdueRentalDto(int reservationId, String reservationCode, int equipmentId, int customerId, int branchId, Date endDate, int overdueDays, double lateFee) {
        this.reservationId = reservationId;
        this.reservationCode = reservationCode;
        this.equipmentId = equipmentId;
        this.customerId = customerId;
        this.branchId = branchId;
        this.endDate = endDate;
        this.overdueDays = overdueDays;
        this.lateFee = lateFee;
    }

    /**
     * @return the reservationId
     */
    public int getReservationId() {
        return reservationId;
    }

    /**
     * @param reservationId the reservationId to set
     */
    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    /**
     * @return the reservationCode
     */
    public String getReservationCode() {
        return reservationCode;
    }

    /**
     * @param reservationCode the reservationCode to set
     */
    public void setReservationCode(String reservationCode) {
        this.reservationCode = reservationCode;
    }

    /**
     * @return the equipmentId
     */
    public int getEquipmentId() {
        return equipmentId;
    }

    /**
     * @param equipmentId the equipmentId to set
     */
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    /**
     * @return the customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the branchId
     */
    public int getBranchId() {
        return branchId;
    }

    /**
     * @param branchId the branchId to set
     */
    public void setBranchId(int branchId) {
        this.branchId = branchId;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the overdueDays
     */
    public int getOverdueDays() {
        return overdueDays;
    }

    /**
     * @param overdueDays the overdueDays to set
     */
    public void setOverdueDays(int overdueDays) {
        this.overdueDays = overdueDays;
    }

    /**
     * @return the lateFee
     */
    public double getLateFee() {
        return lateFee;
    }

    /**
     * @param lateFee the lateFee to set
     */
    public void setLateFee(double lateFee) {
        this.lateFee = lateFee;
    }

    @Override
    public String toString() {
        return "OverdueRentalDto{" + "reservationId=" + reservationId + ", reservationCode=" + reservationCode + ", equipmentId=" + equipmentId + ", customerId=" + customerId + ", branchId=" + branchId + ", endDate=" + endDate + ", overdueDays=" + overdueDays + ", lateFee=" + lateFee + '}';
    }
    
    
    
}
