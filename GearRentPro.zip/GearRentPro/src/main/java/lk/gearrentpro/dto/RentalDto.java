/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dto;
import java.util.Date;

/**
 *
 * @author asus
 */
public class RentalDto {
    private int rentalId;
    private String rentalCode;
    private int equipmentId;
    private int customerId;
    private int branchId;
    private Date startDate;
    private Date endDate;
    private double rentalAmount;
    private double securityDeposit;
    private double membershipDiscountPct;
    private double longRentalDiscountPct;
    private double finalPayableAmount;
    private String paymentStatus;
    private String rentalStatus;
    private Date actualReturnDate;
    private String damageDescription;
    private double damageCharge;
    private double lateFeeTotal;

    public RentalDto() {
    }

    public RentalDto(int rentalId, String rentalCode, int equipmentId, int customerId, int branchId, Date startDate, Date endDate, double rentalAmount, double securityDeposit, double membershipDiscountPct, double longRentalDiscountPct, double finalPayableAmount, String paymentStatus, String rentalStatus, Date actualReturnDate, String damageDescription, double damageCharge, double lateFeeTotal) {
        this.rentalId = rentalId;
        this.rentalCode = rentalCode;
        this.equipmentId = equipmentId;
        this.customerId = customerId;
        this.branchId = branchId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.rentalAmount = rentalAmount;
        this.securityDeposit = securityDeposit;
        this.membershipDiscountPct = membershipDiscountPct;
        this.longRentalDiscountPct = longRentalDiscountPct;
        this.finalPayableAmount = finalPayableAmount;
        this.paymentStatus = paymentStatus;
        this.rentalStatus = rentalStatus;
        this.actualReturnDate = actualReturnDate;
        this.damageDescription = damageDescription;
        this.damageCharge = damageCharge;
        this.lateFeeTotal = lateFeeTotal;
    }
    public RentalDto(String rentalCode, int equipmentId, int customerId, int branchId, Date startDate, Date endDate, double rentalAmount, double securityDeposit, double membershipDiscountPct, double longRentalDiscountPct, double finalPayableAmount, String paymentStatus, String rentalStatus, Date actualReturnDate, String damageDescription, double damageCharge, double lateFeeTotal) {
        this.rentalCode = rentalCode;
        this.equipmentId = equipmentId;
        this.customerId = customerId;
        this.branchId = branchId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.rentalAmount = rentalAmount;
        this.securityDeposit = securityDeposit;
        this.membershipDiscountPct = membershipDiscountPct;
        this.longRentalDiscountPct = longRentalDiscountPct;
        this.finalPayableAmount = finalPayableAmount;
        this.paymentStatus = paymentStatus;
        this.rentalStatus = rentalStatus;
        this.actualReturnDate = actualReturnDate;
        this.damageDescription = damageDescription;
        this.damageCharge = damageCharge;
        this.lateFeeTotal = lateFeeTotal;
    }

    /**
     * @return the rentalId
     */
    public int getRentalId() {
        return rentalId;
    }

    /**
     * @param rentalId the rentalId to set
     */
    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }

    /**
     * @return the rentalCode
     */
    public String getRentalCode() {
        return rentalCode;
    }

    /**
     * @param rentalCode the rentalCode to set
     */
    public void setRentalCode(String rentalCode) {
        this.rentalCode = rentalCode;
    }

    /**
     * @return the equipmentId
     */
    public int getEquipmentId() {
        return equipmentId;
    }

    /**
     * @param equipmentId the equipmentId to set
     */
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    /**
     * @return the customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the branchId
     */
    public int getBranchId() {
        return branchId;
    }

    /**
     * @param branchId the branchId to set
     */
    public void setBranchId(int branchId) {
        this.branchId = branchId;
    }

    /**
     * @return the startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @param startDate the startDate to set
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate the endDate to set
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the rentalAmount
     */
    public double getRentalAmount() {
        return rentalAmount;
    }

    /**
     * @param rentalAmount the rentalAmount to set
     */
    public void setRentalAmount(double rentalAmount) {
        this.rentalAmount = rentalAmount;
    }

    /**
     * @return the securityDeposit
     */
    public double getSecurityDeposit() {
        return securityDeposit;
    }

    /**
     * @param securityDeposit the securityDeposit to set
     */
    public void setSecurityDeposit(double securityDeposit) {
        this.securityDeposit = securityDeposit;
    }

    /**
     * @return the membershipDiscountPct
     */
    public double getMembershipDiscountPct() {
        return membershipDiscountPct;
    }

    /**
     * @param membershipDiscountPct the membershipDiscountPct to set
     */
    public void setMembershipDiscountPct(double membershipDiscountPct) {
        this.membershipDiscountPct = membershipDiscountPct;
    }

    /**
     * @return the longRentalDiscountPct
     */
    public double getLongRentalDiscountPct() {
        return longRentalDiscountPct;
    }

    /**
     * @param longRentalDiscountPct the longRentalDiscountPct to set
     */
    public void setLongRentalDiscountPct(double longRentalDiscountPct) {
        this.longRentalDiscountPct = longRentalDiscountPct;
    }

    /**
     * @return the finalPayableAmount
     */
    public double getFinalPayableAmount() {
        return finalPayableAmount;
    }

    /**
     * @param finalPayableAmount the finalPayableAmount to set
     */
    public void setFinalPayableAmount(double finalPayableAmount) {
        this.finalPayableAmount = finalPayableAmount;
    }

    /**
     * @return the paymentStatus
     */
    public String getPaymentStatus() {
        return paymentStatus;
    }

    /**
     * @param paymentStatus the paymentStatus to set
     */
    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    /**
     * @return the rentalStatus
     */
    public String getRentalStatus() {
        return rentalStatus;
    }

    /**
     * @param rentalStatus the rentalStatus to set
     */
    public void setRentalStatus(String rentalStatus) {
        this.rentalStatus = rentalStatus;
    }

    /**
     * @return the actualReturnDate
     */
    public Date getActualReturnDate() {
        return actualReturnDate;
    }

    /**
     * @param actualReturnDate the actualReturnDate to set
     */
    public void setActualReturnDate(Date actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }

    /**
     * @return the damageDescription
     */
    public String getDamageDescription() {
        return damageDescription;
    }

    /**
     * @param damageDescription the damageDescription to set
     */
    public void setDamageDescription(String damageDescription) {
        this.damageDescription = damageDescription;
    }

    /**
     * @return the damageCharge
     */
    public double getDamageCharge() {
        return damageCharge;
    }

    /**
     * @param damageCharge the damageCharge to set
     */
    public void setDamageCharge(double damageCharge) {
        this.damageCharge = damageCharge;
    }

    /**
     * @return the lateFeeTotal
     */
    public double getLateFeeTotal() {
        return lateFeeTotal;
    }

    /**
     * @param lateFeeTotal the lateFeeTotal to set
     */
    public void setLateFeeTotal(double lateFeeTotal) {
        this.lateFeeTotal = lateFeeTotal;
    }

    @Override
    public String toString() {
        return "RentalDto{" + "rentalId=" + rentalId + ", rentalCode=" + rentalCode + ", equipmentId=" + equipmentId + ", customerId=" + customerId + ", branchId=" + branchId + ", startDate=" + startDate + ", endDate=" + endDate + ", rentalAmount=" + rentalAmount + ", securityDeposit=" + securityDeposit + ", membershipDiscountPct=" + membershipDiscountPct + ", longRentalDiscountPct=" + longRentalDiscountPct + ", finalPayableAmount=" + finalPayableAmount + ", paymentStatus=" + paymentStatus + ", rentalStatus=" + rentalStatus + ", actualReturnDate=" + actualReturnDate + ", damageDescription=" + damageDescription + ", damageCharge=" + damageCharge + ", lateFeeTotal=" + lateFeeTotal + '}';
    }
    
    
    
    
    
}
