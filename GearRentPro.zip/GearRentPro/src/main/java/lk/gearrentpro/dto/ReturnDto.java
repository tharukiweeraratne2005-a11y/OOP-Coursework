/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dto;
import java.util.Date;

/**
 *
 * @author asus
 */
public class ReturnDto {
    private int returnId;
    private int rentalId;
    private int equipmentId;
    private int customerId;
    private Date returnDate;
    private double damageCharge;
    private double lateFee;

    public ReturnDto() {
    }

    public ReturnDto(int returnId, int rentalId, int equipmentId, int customerId, Date returnDate, double damageCharge, double lateFee) {
        this.returnId = returnId;
        this.rentalId = rentalId;
        this.equipmentId = equipmentId;
        this.customerId = customerId;
        this.returnDate = returnDate;
        this.damageCharge = damageCharge;
        this.lateFee = lateFee;
    }

    /**
     * @return the returnId
     */
    public int getReturnId() {
        return returnId;
    }

    /**
     * @param returnId the returnId to set
     */
    public void setReturnId(int returnId) {
        this.returnId = returnId;
    }

    /**
     * @return the rentalId
     */
    public int getRentalId() {
        return rentalId;
    }

    /**
     * @param rentalId the rentalId to set
     */
    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }

    /**
     * @return the equipmentId
     */
    public int getEquipmentId() {
        return equipmentId;
    }

    /**
     * @param equipmentId the equipmentId to set
     */
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    /**
     * @return the customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the returnDate
     */
    public Date getReturnDate() {
        return returnDate;
    }

    /**
     * @param returnDate the returnDate to set
     */
    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    /**
     * @return the damageCharge
     */
    public double getDamageCharge() {
        return damageCharge;
    }

    /**
     * @param damageCharge the damageCharge to set
     */
    public void setDamageCharge(double damageCharge) {
        this.damageCharge = damageCharge;
    }

    /**
     * @return the lateFee
     */
    public double getLateFee() {
        return lateFee;
    }

    /**
     * @param lateFee the lateFee to set
     */
    public void setLateFee(double lateFee) {
        this.lateFee = lateFee;
    }

    @Override
    public String toString() {
        return "ReturnDto{" + "returnId=" + returnId + ", rentalId=" + rentalId + ", equipmentId=" + equipmentId + ", customerId=" + customerId + ", returnDate=" + returnDate + ", damageCharge=" + damageCharge + ", lateFee=" + lateFee + '}';
    }
    
    
    
}
