/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dto;

/**
 *
 * @author asus
 */
public class EquipmentUtilizationReportDto {
    private int equipmentId;
    private String equipmentCode;
    private String brand;
    private String model;
    private long daysRented;
    private long totalDays;
    private double utilization;

    public EquipmentUtilizationReportDto() {
    }

    public EquipmentUtilizationReportDto(int equipmentId, String equipmentCode, String brand, String model, long daysRented, long totalDays, double utilization) {
        this.equipmentId = equipmentId;
        this.equipmentCode = equipmentCode;
        this.brand = brand;
        this.model = model;
        this.daysRented = daysRented;
        this.totalDays = totalDays;
        this.utilization = utilization;
    }

    /**
     * @return the equipmentId
     */
    public int getEquipmentId() {
        return equipmentId;
    }

    /**
     * @param equipmentId the equipmentId to set
     */
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    /**
     * @return the equipmentCode
     */
    public String getEquipmentCode() {
        return equipmentCode;
    }

    /**
     * @param equipmentCode the equipmentCode to set
     */
    public void setEquipmentCode(String equipmentCode) {
        this.equipmentCode = equipmentCode;
    }

    /**
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand the brand to set
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * @return the daysRented
     */
    public long getDaysRented() {
        return daysRented;
    }

    /**
     * @param daysRented the daysRented to set
     */
    public void setDaysRented(long daysRented) {
        this.daysRented = daysRented;
    }

    /**
     * @return the totalDays
     */
    public long getTotalDays() {
        return totalDays;
    }

    /**
     * @param totalDays the totalDays to set
     */
    public void setTotalDays(long totalDays) {
        this.totalDays = totalDays;
    }

    /**
     * @return the utilization
     */
    public double getUtilization() {
        return utilization;
    }

    /**
     * @param utilization the utilization to set
     */
    public void setUtilization(double utilization) {
        this.utilization = utilization;
    }

    @Override
    public String toString() {
        return "EquipmentUtilizationReportDto{" + "equipmentId=" + equipmentId + ", equipmentCode=" + equipmentCode + ", brand=" + brand + ", model=" + model + ", daysRented=" + daysRented + ", totalDays=" + totalDays + ", utilization=" + utilization + '}';
    }
    
    public double getUtilizationPercentage() {
    if (totalDays == 0) {
        return 0.0;
    }
    return (daysRented * 100.0) / totalDays;
}


    
    
    
}
