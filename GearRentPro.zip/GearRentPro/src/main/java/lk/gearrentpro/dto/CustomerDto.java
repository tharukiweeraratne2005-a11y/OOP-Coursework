/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dto;

/**
 *
 * @author asus
 */
public class CustomerDto {

    private int customerId;
    private String customerCode;
    private String name;
    private String nicPassport;
    private String contactNo;
    private String email;
    private String address;
    private String membership;

    public CustomerDto() {}

    // save
    public CustomerDto(String customerCode, String name, String nicPassport,
                       String contactNo, String email, String address, String membership) {
        this.customerCode = customerCode;
        this.name = name;
        this.nicPassport = nicPassport;
        this.contactNo = contactNo;
        this.email = email;
        this.address = address;
        this.membership = membership;
    }

    // update / view
    public CustomerDto(int customerId, String customerCode, String name,
                       String nicPassport, String contactNo, String email,
                       String address, String membership) {
        this.customerId = customerId;
        this.customerCode = customerCode;
        this.name = name;
        this.nicPassport = nicPassport;
        this.contactNo = contactNo;
        this.email = email;
        this.address = address;
        this.membership = membership;
    }

    /**
     * @return the customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the customerId to set
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the customerCode
     */
    public String getCustomerCode() {
        return customerCode;
    }

    /**
     * @param customerCode the customerCode to set
     */
    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the nicPassport
     */
    public String getNicPassport() {
        return nicPassport;
    }

    /**
     * @param nicPassport the nicPassport to set
     */
    public void setNicPassport(String nicPassport) {
        this.nicPassport = nicPassport;
    }

    /**
     * @return the contactNo
     */
    public String getContactNo() {
        return contactNo;
    }

    /**
     * @param contactNo the contactNo to set
     */
    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the membership
     */
    public String getMembership() {
        return membership;
    }

    /**
     * @param membership the membership to set
     */
    public void setMembership(String membership) {
        this.membership = membership;
    }

    @Override
    public String toString() {
        return "CustomerDto{" + "customerId=" + customerId + ", customerCode=" + customerCode + ", name=" + name + ", nicPassport=" + nicPassport + ", contactNo=" + contactNo + ", email=" + email + ", address=" + address + ", membership=" + membership + '}';
    }

    
    
}
