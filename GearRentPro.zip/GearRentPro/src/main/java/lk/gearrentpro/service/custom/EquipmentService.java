/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;

import java.util.List;
import lk.gearrentpro.dto.EquipmentDto;

/**
 *
 * @author asus
 */
public interface EquipmentService {
    
    boolean saveEquipment(EquipmentDto dto);
    boolean updateEquipment(EquipmentDto dto);
    boolean deleteEquipment(int equipmentId);
    EquipmentDto getEquipmentById(int equipmentId);
    List<EquipmentDto> getAllEquipment();
    
}
