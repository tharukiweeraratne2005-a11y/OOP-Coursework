/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;

import java.util.List;
import java.util.stream.Collectors;

import lk.gearrentpro.dao.custom.BranchDao;
import lk.gearrentpro.dao.custom.impl.BranchDaoImpl;
import lk.gearrentpro.dto.BranchDto;
import lk.gearrentpro.entity.BranchEntity;
import lk.gearrentpro.service.custom.BranchService;

/**
 *
 * @author asus
 */
public class BranchServiceImpl implements BranchService {
    private final BranchDao branchDao = new BranchDaoImpl();

    @Override
    public boolean saveBranch(BranchDto branchDto) {
         // basic validation (business logic)
        if (branchDto.getCode() == null || branchDto.getCode().isEmpty()) return false;
        if (branchDto.getName() == null || branchDto.getName().isEmpty()) return false;

        BranchEntity branch = new BranchEntity(
                branchDto.getCode(),
                branchDto.getName(),
                branchDto.getAddress(),
                branchDto.getContact()
        );

        return branchDao.save(branch);
    }

    @Override
    public boolean updateBranch(BranchDto branchDto) {
          BranchEntity branch = new BranchEntity(
                branchDto.getBranchId(),
                branchDto.getCode(),
                branchDto.getName(),
                branchDto.getAddress(),
                branchDto.getContact()
        );

        return branchDao.update(branch);
    }

    @Override
    public boolean deleteBranch(int branchId) {
          return branchDao.delete(branchId);
    }

    @Override
    public BranchDto getBranchById(int branchId) {
        BranchEntity branch = branchDao.findById(branchId);

        if (branch == null) return null;

        return new BranchDto(
                branch.getBranchId(),
                branch.getCode(),
                branch.getName(),
                branch.getAddress(),
                branch.getContact()
        );
    }

    @Override
    public List<BranchDto> getAllBranches() {
         return branchDao.findAll()
                .stream()
                .map(b -> new BranchDto(
                        b.getBranchId(),
                        b.getCode(),
                        b.getName(),
                        b.getAddress(),
                        b.getContact()
                ))
                .collect(Collectors.toList());
    }
    
}
