/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;
import java.util.ArrayList;
import java.util.List;
import lk.gearrentpro.dto.BranchRevenueReportDto;
import lk.gearrentpro.dto.EquipmentUtilizationReportDto;


/**
 *
 * @author asus
 */
public interface ReportService {
    List<BranchRevenueReportDto> getBranchRevenueReport() throws Exception;
    List<EquipmentUtilizationReportDto> getEquipmentUtilizationReport() throws Exception;
}
