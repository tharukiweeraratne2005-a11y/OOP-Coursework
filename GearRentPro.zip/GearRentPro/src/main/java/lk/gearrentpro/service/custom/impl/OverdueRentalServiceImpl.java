/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import java.util.List;

import lk.gearrentpro.dao.custom.OverdueRentalDao;
import lk.gearrentpro.dao.custom.impl.OverdueRentalDaoImpl;
import lk.gearrentpro.dto.OverdueRentalDto;
import lk.gearrentpro.service.custom.OverdueRentalService;

/**
 *
 * @author asus
 */
public class OverdueRentalServiceImpl implements OverdueRentalService {
     private final OverdueRentalDao dao = new OverdueRentalDaoImpl();

    @Override
    public List<OverdueRentalDto> getAllOverdueRentals() {
        return dao.findAllOverdue();
    }
    
}
