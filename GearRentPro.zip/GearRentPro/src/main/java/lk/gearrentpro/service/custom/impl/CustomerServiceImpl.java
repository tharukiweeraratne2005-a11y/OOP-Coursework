/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import lk.gearrentpro.dao.custom.impl.CustomerDaoImpl;
import lk.gearrentpro.entity.CustomerEntity;

import java.util.List;
import java.util.stream.Collectors;
import lk.gearrentpro.dao.custom.CustomerDao;
import lk.gearrentpro.dto.CustomerDto;
import lk.gearrentpro.service.custom.CustomerService;

/**
 *
 * @author asus
 */
public class CustomerServiceImpl implements CustomerService {
    private final CustomerDao customerDao = new CustomerDaoImpl();

    @Override
    public boolean saveCustomer(CustomerDto dto) {

        // basic validation (business rules)
        if (dto.getCustomerCode() == null || dto.getCustomerCode().isEmpty()) return false;
        if (dto.getName() == null || dto.getName().isEmpty()) return false;

        CustomerEntity customer = new CustomerEntity(
                dto.getCustomerCode(),
                dto.getName(),
                dto.getNicPassport(),
                dto.getContactNo(),
                dto.getEmail(),
                dto.getAddress(),
                dto.getMembership()
        );

        return customerDao.save(customer);
    }

    @Override
    public boolean updateCustomer(CustomerDto dto) {

        CustomerEntity customer = new CustomerEntity(
                dto.getCustomerId(),
                dto.getCustomerCode(),
                dto.getName(),
                dto.getNicPassport(),
                dto.getContactNo(),
                dto.getEmail(),
                dto.getAddress(),
                dto.getMembership()
        );

        return customerDao.update(customer);
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        return customerDao.delete(customerId);
    }

    @Override
    public CustomerDto getCustomerById(int customerId) {

        CustomerEntity customer = customerDao.findById(customerId);
        if (customer == null) return null;

        return new CustomerDto(
                customer.getCustomerId(),
                customer.getCustomerCode(),
                customer.getName(),
                customer.getNicPassport(),
                customer.getContactNo(),
                customer.getEmail(),
                customer.getAddress(),
                customer.getMembership()
        );
    }

    @Override
    public List<CustomerDto> getAllCustomers() {

        return customerDao.findAll()
                .stream()
                .map(c -> new CustomerDto(
                        c.getCustomerId(),
                        c.getCustomerCode(),
                        c.getName(),
                        c.getNicPassport(),
                        c.getContactNo(),
                        c.getEmail(),
                        c.getAddress(),
                        c.getMembership()
                ))
                .collect(Collectors.toList());
    }
}



