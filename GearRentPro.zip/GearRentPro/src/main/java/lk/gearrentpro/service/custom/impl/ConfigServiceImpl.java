/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import lk.gearrentpro.dao.custom.ConfigDao;
import lk.gearrentpro.dao.custom.impl.ConfigDaoImpl;
import lk.gearrentpro.entity.ConfigEntity;
import lk.gearrentpro.service.custom.ConfigService;

/**
 *
 * @author asus
 */
public class ConfigServiceImpl implements ConfigService {
     private final ConfigDao configDao = new ConfigDaoImpl();

    @Override
    public ConfigEntity getConfigByKey(String cfgKey) {
        return configDao.findByKey(cfgKey);
    }

    @Override
    public boolean saveConfig(ConfigEntity config) {
        return configDao.save(config);
    }

    @Override
    public boolean updateConfig(ConfigEntity config) {
        return configDao.update(config);
    }

    @Override
    public boolean deleteConfig(String cfgKey) {
        return configDao.delete(cfgKey);
    }
    
}
