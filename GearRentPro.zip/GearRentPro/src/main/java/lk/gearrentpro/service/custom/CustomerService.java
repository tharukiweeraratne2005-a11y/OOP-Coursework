/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;
import lk.gearrentpro.entity.CustomerEntity;
import java.util.List;
import lk.gearrentpro.dto.CustomerDto;

/**
 *
 * @author asus
 */
public interface CustomerService {
    boolean saveCustomer(CustomerDto dto);
    boolean updateCustomer(CustomerDto dto);
    boolean deleteCustomer(int customerId);
    CustomerDto getCustomerById(int customerId);
    List<CustomerDto> getAllCustomers();
    
}
