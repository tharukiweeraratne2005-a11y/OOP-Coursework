/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;

import java.util.List;
import java.util.stream.Collectors;

import lk.gearrentpro.dao.custom.ReservationDao;
import lk.gearrentpro.dao.custom.impl.ReservationDaoImpl;
import lk.gearrentpro.dto.ReservationDto;
import lk.gearrentpro.entity.ReservationEntity;
import lk.gearrentpro.service.custom.ReservationService;

/**
 *
 * @author asus
 */
public class ReservationServiceImpl implements ReservationService {
     private final ReservationDao dao = new ReservationDaoImpl();

    @Override
    public boolean saveReservation(ReservationDto d) {
        return dao.save(new ReservationEntity(
                d.getReservationCode(),
                d.getEquipmentId(),
                d.getCustomerId(),
                d.getBranchId(),
                d.getStartDate(),
                d.getEndDate(),
                d.getStatus()
        ));
    }

    @Override
    public boolean updateReservation(ReservationDto d) {
        return dao.update(new ReservationEntity(
                d.getReservationId(),
                d.getReservationCode(),
                d.getEquipmentId(),
                d.getCustomerId(),
                d.getBranchId(),
                d.getStartDate(),
                d.getEndDate(),
                d.getStatus()
        ));
    }

    @Override
    public boolean deleteReservation(int reservationId) {
        return dao.delete(reservationId);
    }

    @Override
    public List<ReservationDto> getAllReservations() {
        return dao.findAll().stream()
                .map(r -> new ReservationDto(
                        r.getReservationId(),
                        r.getReservationCode(),
                        r.getEquipmentId(),
                        r.getCustomerId(),
                        r.getBranchId(),
                        r.getStartDate(),
                        r.getEndDate(),
                        r.getStatus()
                ))
                .collect(Collectors.toList());
    }
    
}
