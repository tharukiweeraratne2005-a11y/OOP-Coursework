/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;

import java.util.List;
import lk.gearrentpro.dto.CategoryDto;

/**
 *
 * @author asus
 */
public interface CategoryService {
    boolean save(CategoryDto dto) throws Exception;
    boolean update(CategoryDto dto) throws Exception;
    boolean delete(int id) throws Exception;
    List<CategoryDto> getAll() throws Exception;
    
}
