/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import java.util.List;
import java.util.stream.Collectors;

import lk.gearrentpro.dao.custom.UserDao;
import lk.gearrentpro.dao.custom.impl.UserDaoImpl;
import lk.gearrentpro.dto.UserDto;
import lk.gearrentpro.entity.UserEntity;
import lk.gearrentpro.service.custom.UserService;

/**
 *
 * @author asus
 */
public class UserServiceImpl implements UserService {
    private final UserDao dao = new UserDaoImpl();

    @Override
    public boolean saveUser(UserDto dto) {
        return dao.save(new UserEntity(
                dto.getUsername(),
                dto.getPasswordHash(),
                dto.getRole(),
                dto.getBranchId(),
                dto.getFullName()
        ));
    }

    @Override
    public boolean updateUser(UserDto dto) {
         return dao.update(new UserEntity(
                dto.getUserId(),
                dto.getUsername(),
                dto.getPasswordHash(),
                dto.getRole(),
                dto.getBranchId(),
                dto.getFullName()
        ));
    }

    @Override
    public boolean deleteUser(int id) {
        return dao.delete(id);
    }

    @Override
    public List<UserDto> getAllUsers() {
        return dao.findAll().stream()
                .map(u -> new UserDto(
                        u.getUserId(),
                        u.getUsername(),
                        u.getPasswordHash(),
                        u.getRole(),
                        u.getBranchId(),
                        u.getFullName()
                ))
                .collect(Collectors.toList());
    }
    
}
