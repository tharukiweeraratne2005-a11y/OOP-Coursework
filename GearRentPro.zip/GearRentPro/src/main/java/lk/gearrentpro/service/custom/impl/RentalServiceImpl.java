/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;

import java.util.List;
import java.util.stream.Collectors;

import lk.gearrentpro.dao.custom.RentalDao;
import lk.gearrentpro.dao.custom.impl.RentalDaoImpl;
import lk.gearrentpro.dto.RentalDto;
import lk.gearrentpro.entity.RentalEntity;
import lk.gearrentpro.service.custom.RentalService;

/**
 *
 * @author asus
 */
public class RentalServiceImpl implements RentalService{
     private final RentalDao rentalDao = new RentalDaoImpl();

    @Override
    public boolean saveRental(RentalDto dto) {
        RentalEntity entity = new RentalEntity(
                dto.getRentalCode(),
                dto.getEquipmentId(),
                dto.getCustomerId(),
                dto.getBranchId(),
                dto.getStartDate(),
                dto.getEndDate(),
                dto.getRentalAmount(),
                dto.getSecurityDeposit(),
                dto.getMembershipDiscountPct(),
                dto.getLongRentalDiscountPct(),
                dto.getFinalPayableAmount(),
                dto.getPaymentStatus(),
                dto.getRentalStatus(),
                dto.getActualReturnDate(),
                dto.getDamageDescription(),
                dto.getDamageCharge(),
                dto.getLateFeeTotal()
        );

        return rentalDao.save(entity);
    }
    

    @Override
    public boolean updateRental(RentalDto dto) {
         RentalEntity entity = new RentalEntity(
                dto.getRentalId(),
                dto.getRentalCode(),
                dto.getEquipmentId(),
                dto.getCustomerId(),
                dto.getBranchId(),
                dto.getStartDate(),
                dto.getEndDate(),
                dto.getRentalAmount(),
                dto.getSecurityDeposit(),
                dto.getMembershipDiscountPct(),
                dto.getLongRentalDiscountPct(),
                dto.getFinalPayableAmount(),
                dto.getPaymentStatus(),
                dto.getRentalStatus(),
                dto.getActualReturnDate(),
                dto.getDamageDescription(),
                dto.getDamageCharge(),
                dto.getLateFeeTotal()
        );

        return rentalDao.update(entity);
    }

    @Override
    public boolean deleteRental(int rentalId) {
        return rentalDao.delete(rentalId);
    }

    @Override
    public RentalDto getRentalById(int rentalId) {
        RentalEntity r = rentalDao.findById(rentalId);
        if (r == null) return null;

        return new RentalDto(
                r.getRentalId(),
                r.getRentalCode(),
                r.getEquipmentId(),
                r.getCustomerId(),
                r.getBranchId(),
                r.getStartDate(),
                r.getEndDate(),
                r.getRentalAmount(),
                r.getSecurityDeposit(),
                r.getMembershipDiscountPct(),
                r.getLongRentalDiscountPct(),
                r.getFinalPayableAmount(),
                r.getPaymentStatus(),
                r.getRentalStatus(),
                r.getActualReturnDate(),
                r.getDamageDescription(),
                r.getDamageCharge(),
                r.getLateFeeTotal()
        );
    }

    @Override
    public List<RentalDto> getAllRentals() {
         return rentalDao.findAll()
                .stream()
                .map(r -> new RentalDto(
                        r.getRentalId(),
                        r.getRentalCode(),
                        r.getEquipmentId(),
                        r.getCustomerId(),
                        r.getBranchId(),
                        r.getStartDate(),
                        r.getEndDate(),
                        r.getRentalAmount(),
                        r.getSecurityDeposit(),
                        r.getMembershipDiscountPct(),
                        r.getLongRentalDiscountPct(),
                        r.getFinalPayableAmount(),
                        r.getPaymentStatus(),
                        r.getRentalStatus(),
                        r.getActualReturnDate(),
                        r.getDamageDescription(),
                        r.getDamageCharge(),
                        r.getLateFeeTotal()
                ))
                .collect(Collectors.toList());
    }
    }
    

