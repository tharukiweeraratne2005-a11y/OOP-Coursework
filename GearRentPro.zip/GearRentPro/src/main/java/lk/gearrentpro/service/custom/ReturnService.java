/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;

import java.util.List;
import lk.gearrentpro.dto.ReturnDto;

/**
 *
 * @author asus
 */
public interface ReturnService {
    boolean saveReturn(ReturnDto dto);
    boolean updateReturn(ReturnDto dto);
    boolean deleteReturn(int returnId);
    List<ReturnDto> getAllReturns();
    ReturnDto getReturnById(int returnId);
    
    
}
