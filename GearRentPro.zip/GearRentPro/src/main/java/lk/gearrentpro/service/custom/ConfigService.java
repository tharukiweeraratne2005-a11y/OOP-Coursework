/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;
import lk.gearrentpro.entity.ConfigEntity;

/**
 *
 * @author asus
 */
public interface ConfigService {
    ConfigEntity getConfigByKey(String cfgKey);
    boolean saveConfig(ConfigEntity config);
    boolean updateConfig(ConfigEntity config);
    boolean deleteConfig(String cfgKey);
    
}
