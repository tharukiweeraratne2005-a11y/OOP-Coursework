/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import lk.gearrentpro.dto.ReturnDto;
import lk.gearrentpro.entity.ReturnEntity;
import lk.gearrentpro.dao.custom.ReturnDao;
import lk.gearrentpro.dao.custom.impl.ReturnDaoImpl;
import lk.gearrentpro.service.custom.ReturnService;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author asus
 */
public class ReturnServiceImpl implements ReturnService {
     
private final ReturnDao returnDao = new ReturnDaoImpl();

  private ReturnDto toDto(ReturnEntity entity) {
        return new ReturnDto(
                entity.getReturnId(),
                entity.getRentalId(),
                entity.getEquipmentId(),
                entity.getCustomerId(),
                entity.getReturnDate(),
                entity.getDamageCharge(),
                entity.getLateFee()
        );
    }

    private ReturnEntity toEntity(ReturnDto dto) {
        return new ReturnEntity(
                dto.getReturnId(),
                dto.getRentalId(),
                dto.getEquipmentId(),
                dto.getCustomerId(),
                dto.getReturnDate(),
                dto.getDamageCharge(),
                dto.getLateFee()
        );
    }

    @Override
    public boolean saveReturn(ReturnDto dto) {
        return returnDao.save(toEntity(dto));
    }

    @Override
    public boolean updateReturn(ReturnDto dto) {
        return returnDao.update(toEntity(dto));
    }

    @Override
    public boolean deleteReturn(int returnId) {
        return returnDao.delete(returnId);
    }

    @Override
    public List<ReturnDto> getAllReturns() {
        return returnDao.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public ReturnDto getReturnById(int returnId) {
        ReturnEntity entity = returnDao.findById(returnId);
        return entity == null ? null : toDto(entity);
    } 
}
