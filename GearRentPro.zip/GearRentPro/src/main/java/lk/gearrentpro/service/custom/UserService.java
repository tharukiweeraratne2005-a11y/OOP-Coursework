/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;
import java.util.List;
import lk.gearrentpro.dto.UserDto;

/**
 *
 * @author asus
 */
public interface UserService {
    boolean saveUser(UserDto dto);
    boolean updateUser(UserDto dto);
    boolean deleteUser(int id);
    List<UserDto> getAllUsers();
    
}
