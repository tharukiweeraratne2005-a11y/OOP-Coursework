/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;
import java.util.List;
import lk.gearrentpro.dto.BranchDto;
/**
 *
 * @author asus
 */
public interface BranchService {
    boolean saveBranch(BranchDto branchDto);

    boolean updateBranch(BranchDto branchDto);

    boolean deleteBranch(int branchId);

    BranchDto getBranchById(int branchId);

    List<BranchDto> getAllBranches();
    
}
