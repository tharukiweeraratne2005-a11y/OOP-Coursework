/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.service.custom;
import java.util.List;

import lk.gearrentpro.dto.RentalDto;

/**
 *
 * @author asus
 */
public interface RentalService {
    boolean saveRental(RentalDto dto);

    boolean updateRental(RentalDto dto);

    boolean deleteRental(int rentalId);

    RentalDto getRentalById(int rentalId);

    List<RentalDto> getAllRentals();
    
}
