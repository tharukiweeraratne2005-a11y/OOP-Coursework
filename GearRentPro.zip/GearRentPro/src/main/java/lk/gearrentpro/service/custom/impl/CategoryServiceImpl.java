/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import java.util.ArrayList;
import java.util.List;
import lk.gearrentpro.dao.custom.CategoryDao;
import lk.gearrentpro.dao.custom.impl.CategoryDaoImpl;
import lk.gearrentpro.dto.CategoryDto;
import lk.gearrentpro.entity.CategoryEntity;
import lk.gearrentpro.service.custom.CategoryService;
import lk.gearrentpro.service.custom.CategoryService;


/**
 *
 * @author asus
 */
public class CategoryServiceImpl implements CategoryService  {
     private final CategoryDao dao = new CategoryDaoImpl();

    @Override
    public boolean save(CategoryDto dto) throws Exception {
          return dao.save(new CategoryEntity(
                dto.getName(),
                dto.getDescription(),
                dto.getBasePriceFactor(),
                dto.getWeekendMultiplier(),
                dto.getDefaultLateFeePerDay(),
                dto.isActive()
        ));
    }

    @Override
    public boolean update(CategoryDto dto) throws Exception {
        return dao.update(new CategoryEntity(
                dto.getCategoryId(),
                dto.getName(),
                dto.getDescription(),
                dto.getBasePriceFactor(),
                dto.getWeekendMultiplier(),
                dto.getDefaultLateFeePerDay(),
                dto.isActive()
        ));
    }

    @Override
    public boolean delete(int id) throws Exception {
        return dao.delete(id);

    }

    @Override
    public List<CategoryDto> getAll() throws Exception {
        List<CategoryDto> list = new ArrayList<>();
        for (CategoryEntity e : dao.getAll()) {
            list.add(new CategoryDto(
                    e.getCategoryId(),
                    e.getName(),
                    e.getDescription(),
                    e.getBasePriceFactor(),
                    e.getWeekendMultiplier(),
                    e.getDefaultLateFeePerDay(),
                    e.isActive()
            ));
        }
        return list;
    }
    
    
}
