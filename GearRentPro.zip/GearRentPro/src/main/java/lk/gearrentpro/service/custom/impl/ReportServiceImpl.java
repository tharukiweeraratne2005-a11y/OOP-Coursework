/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;
import java.util.ArrayList;
import java.util.List;
import lk.gearrentpro.dao.custom.impl.ReportDaoImpl;
import lk.gearrentpro.dto.BranchRevenueReportDto;
import lk.gearrentpro.dto.EquipmentUtilizationReportDto;
import lk.gearrentpro.entity.BranchRevenueEntity;
import lk.gearrentpro.entity.EquipmentUtilizationEntity;
import lk.gearrentpro.service.custom.ReportService;

/**
 *
 * @author asus
 */
public class ReportServiceImpl implements ReportService {
    private final ReportDaoImpl reportDao = new ReportDaoImpl();

    @Override
    public List<BranchRevenueReportDto> getBranchRevenueReport() throws Exception {
        List<BranchRevenueEntity> entities = reportDao.getRevenueData();
        List<BranchRevenueReportDto> dtos = new ArrayList<>();

        for (BranchRevenueEntity entity : entities) {
            dtos.add(new BranchRevenueReportDto(
                entity.getBranchId(),
                entity.getBranchName(),
                entity.getTotalRentals(),
                entity.getTotalIncome(),
                entity.getTotalLateFees(),
                entity.getTotalDamageCharges()
            ));
        }
        return dtos;
    }

    @Override
    public List<EquipmentUtilizationReportDto> getEquipmentUtilizationReport() throws Exception {
        List<EquipmentUtilizationEntity> entities = reportDao.getUtilizationData();
        List<EquipmentUtilizationReportDto> dtos = new ArrayList<>();

        for (EquipmentUtilizationEntity entity : entities) {
            dtos.add(new EquipmentUtilizationReportDto(
                entity.getEquipmentId(),
                entity.getEquipmentCode(),
                entity.getBrand(),
                entity.getModel(),
                entity.getDaysRented(),
                entity.getTotalTimes(),
                0.0
            ));
        }
        return dtos;
    }
    
}
