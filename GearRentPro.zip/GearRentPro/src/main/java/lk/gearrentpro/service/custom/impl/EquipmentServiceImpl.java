/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.service.custom.impl;

import lk.gearrentpro.service.custom.EquipmentService;
import java.util.List;
import java.util.stream.Collectors;

import lk.gearrentpro.dao.custom.EquipmentDao;
import lk.gearrentpro.dao.custom.impl.EquipmentDaoImpl;
import lk.gearrentpro.dto.EquipmentDto;
import lk.gearrentpro.entity.EquipmentEntity;

/**
 *
 * @author asus
 */
public class EquipmentServiceImpl implements EquipmentService {
      private final EquipmentDao equipmentDao = (EquipmentDao) new EquipmentDaoImpl();


    @Override
    public boolean saveEquipment(EquipmentDto dto) {
        if (dto.getEquipmentCode() == null || dto.getEquipmentCode().isEmpty())
            return false;

        EquipmentEntity entity = new EquipmentEntity(
                dto.getEquipmentCode(),
                dto.getCategoryId(),
                dto.getBrand(),
                dto.getModel(),
                dto.getPurchaseYear(),
                dto.getBaseDailyPrice(),
                dto.getSecurityDeposit(),
                dto.getStatus(),
                dto.getBranchId()
        );

        return equipmentDao.save(entity);
    }
    

    @Override
    public boolean updateEquipment(EquipmentDto dto) {
        EquipmentEntity entity = new EquipmentEntity(
                dto.getEquipmentId(),
                dto.getEquipmentCode(),
                dto.getCategoryId(),
                dto.getBrand(),
                dto.getModel(),
                dto.getPurchaseYear(),
                dto.getBaseDailyPrice(),
                dto.getSecurityDeposit(),
                dto.getStatus(),
                dto.getBranchId()
        );

        return equipmentDao.update(entity);
    }
    

    @Override
    public boolean deleteEquipment(int equipmentId) {
        return equipmentDao.delete(equipmentId);
    }

    @Override
    public EquipmentDto getEquipmentById(int equipmentId) {
        EquipmentEntity e = equipmentDao.findById(equipmentId);
        if (e == null) return null;

        return new EquipmentDto(
                e.getEquipmentId(),
                e.getEquipmentCode(),
                e.getCategoryId(),
                e.getBrand(),
                e.getModel(),
                e.getPurchaseYear(),
                e.getBaseDailyPrice(),
                e.getSecurityDeposit(),
                e.getStatus(),
                e.getBranchId()
        );
    }
    

    @Override
    public List<EquipmentDto> getAllEquipment() {
        return equipmentDao.findAll()
                .stream()
                .map(e -> new EquipmentDto(
                        e.getEquipmentId(),
                        e.getEquipmentCode(),
                        e.getCategoryId(),
                        e.getBrand(),
                        e.getModel(),
                        e.getPurchaseYear(),
                        e.getBaseDailyPrice(),
                        e.getSecurityDeposit(),
                        e.getStatus(),
                        e.getBranchId()
                ))
                .collect(Collectors.toList());
    }
    
}
