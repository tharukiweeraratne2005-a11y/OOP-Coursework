/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;

import lk.gearrentpro.dao.custom.ReturnDao;
import lk.gearrentpro.entity.ReturnEntity;
import lk.gearrentpro.db.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReturnDaoImpl implements ReturnDao {

    @Override
    public boolean save(ReturnEntity r) {
        
        String sql = "INSERT INTO rental_return (return_id, rental_id, equipment_id, customer_id, return_date, damage_charge, late_fee) VALUES(?,?,?,?,?,?,?)";
        
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            stm.setInt(1, r.getReturnId()); 
            stm.setInt(2, r.getRentalId());
            stm.setInt(3, r.getEquipmentId());
            stm.setInt(4, r.getCustomerId());
            stm.setDate(5, new java.sql.Date(r.getReturnDate().getTime()));
            stm.setDouble(6, r.getDamageCharge());
            stm.setDouble(7, r.getLateFee());

            return stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<ReturnEntity> findAll() {
        List<ReturnEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM rental_return ORDER BY return_id ASC";
        
        try (Connection conn = DBConnection.getInstance().getConnection();
             Statement stm = conn.createStatement();
             ResultSet rs = stm.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new ReturnEntity(
                        rs.getInt("return_id"), 
                        rs.getInt("rental_id"),
                        rs.getInt("equipment_id"),
                        rs.getInt("customer_id"),
                        rs.getDate("return_date"), 
                        rs.getDouble("damage_charge"),
                        rs.getDouble("late_fee")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean update(ReturnEntity r) {
        String sql = "UPDATE rental_return SET rental_id=?, equipment_id=?, customer_id=?, return_date=?, damage_charge=?, late_fee=? WHERE return_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {

            stm.setInt(1, r.getRentalId());
            stm.setInt(2, r.getEquipmentId());
            stm.setInt(3, r.getCustomerId());
            stm.setDate(4, new java.sql.Date(r.getReturnDate().getTime()));
            stm.setDouble(5, r.getDamageCharge());
            stm.setDouble(6, r.getLateFee());
            stm.setInt(7, r.getReturnId());

            return stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean delete(int returnId) {
        String sql = "DELETE FROM rental_return WHERE return_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {
            stm.setInt(1, returnId);
            return stm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public ReturnEntity findById(int returnId) {
        String sql = "SELECT * FROM rental_return WHERE return_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement stm = conn.prepareStatement(sql)) {
            stm.setInt(1, returnId);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                return new ReturnEntity(
                        rs.getInt("return_id"),
                        rs.getInt("rental_id"),
                        rs.getInt("equipment_id"),
                        rs.getInt("customer_id"),
                        rs.getDate("return_date"),
                        rs.getDouble("damage_charge"),
                        rs.getDouble("late_fee")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}