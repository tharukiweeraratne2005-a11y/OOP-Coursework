/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;

import lk.gearrentpro.dao.custom.UserDao;
import lk.gearrentpro.entity.UserEntity;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class UserDaoImpl implements UserDao {

    @Override
    public boolean save(UserEntity user) {
        String sql = "INSERT INTO users (username,password_hash,role,branch_id,full_name) VALUES (?,?,?,?,?)";
        try (Connection c = DBConnection.getInstance().getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, user.getUsername());
            p.setString(2, user.getPasswordHash());
            p.setString(3, user.getRole());
            if (user.getBranchId() != null) p.setInt(4, user.getBranchId());
            else p.setNull(4, Types.INTEGER);
            p.setString(5, user.getFullName());
            return p.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(UserEntity user) {
        String sql = "UPDATE users SET username=?,password_hash=?,role=?,branch_id=?,full_name=? WHERE user_id=?";
        try (Connection c = DBConnection.getInstance().getConnection();
             PreparedStatement p = c.prepareStatement(sql)) {

            p.setString(1, user.getUsername());
            p.setString(2, user.getPasswordHash());
            p.setString(3, user.getRole());
            if (user.getBranchId() != null) p.setInt(4, user.getBranchId());
            else p.setNull(4, Types.INTEGER);
            p.setString(5, user.getFullName());
            p.setInt(6, user.getUserId());
            return p.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int userId) {
        try (Connection c = DBConnection.getInstance().getConnection();
             PreparedStatement p = c.prepareStatement("DELETE FROM users WHERE user_id=?")) {
            p.setInt(1, userId);
            return p.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public UserEntity findById(int userId) {
         try (Connection c = DBConnection.getInstance().getConnection();
             PreparedStatement p = c.prepareStatement("SELECT * FROM users WHERE user_id=?")) {
            p.setInt(1, userId);
            ResultSet r = p.executeQuery();
            if (r.next()) {
                return new UserEntity(
                        r.getInt("user_id"),
                        r.getString("username"),
                        r.getString("password_hash"),
                        r.getString("role"),
                        (Integer) r.getObject("branch_id"),
                        r.getString("full_name")
                );
            }
        } catch (Exception e) {}
        return null;
    }

    @Override
    public List<UserEntity> findAll() {
        List<UserEntity> list = new ArrayList<>();
        try (Connection c = DBConnection.getInstance().getConnection();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery("SELECT * FROM users")) {

            while (r.next()) {
                list.add(new UserEntity(
                        r.getInt("user_id"),
                        r.getString("username"),
                        r.getString("password_hash"),
                        r.getString("role"),
                        (Integer) r.getObject("branch_id"),
                        r.getString("full_name")
                ));
            }
        } catch (Exception e) {}
        return list;
    }
    }
    
    

