/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import lk.gearrentpro.dao.custom.EquipmentUtilizationReportDao;
import lk.gearrentpro.dto.EquipmentUtilizationReportDto;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class EquipmentUtilizationReportDaoImpl implements EquipmentUtilizationReportDao{
   @Override
public List<EquipmentUtilizationReportDto> getUtilizationReport(Date startDate, Date endDate) {
    List<EquipmentUtilizationReportDto> list = new ArrayList<>();
    String sql = "SELECT e.equipment_id, e.equipment_code, e.brand, e.model, " +
                 "IFNULL(SUM(DATEDIFF(LEAST(r.actual_return_date, ?), GREATEST(r.start_date, ?))), 0) AS days_rented " +
                 "FROM equipment e " +
                 "LEFT JOIN rental r ON e.equipment_id = r.equipment_id " +
                 "AND r.start_date <= ? AND r.actual_return_date >= ? " +
                 "GROUP BY e.equipment_id, e.equipment_code, e.brand, e.model";

    try (Connection conn = DBConnection.getInstance().getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setDate(1, endDate);
        pst.setDate(2, startDate);
        pst.setDate(3, endDate);
        pst.setDate(4, startDate);

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            long totalDays = java.time.temporal.ChronoUnit.DAYS.between(startDate.toLocalDate(), endDate.toLocalDate()) + 1;
            long daysRented = rs.getLong("days_rented");
            double utilization = (totalDays == 0) ? 0 : (daysRented * 100.0) / totalDays;

            list.add(new EquipmentUtilizationReportDto(
                    rs.getInt("equipment_id"),
                    rs.getString("equipment_code"),
                    rs.getString("brand"),
                    rs.getString("model"),
                    daysRented,
                    totalDays,
                    utilization
            ));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return list;
}
}
