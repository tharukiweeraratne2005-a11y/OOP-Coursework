/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import lk.gearrentpro.dao.custom.CustomerDao;
import lk.gearrentpro.entity.CustomerEntity;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class CustomerDaoImpl implements CustomerDao{
     @Override
    public boolean save(CustomerEntity customer) {
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(
                 "INSERT INTO customer (customer_code,name,nic_passport,contact_no,email,address,membership) VALUES (?,?,?,?,?,?,?)"
             )) {
            pst.setString(1, customer.getCustomerCode());
            pst.setString(2, customer.getName());
            pst.setString(3, customer.getNicPassport());
            pst.setString(4, customer.getContactNo());
            pst.setString(5, customer.getEmail());
            pst.setString(6, customer.getAddress());
            pst.setString(7, customer.getMembership());
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    

   

    @Override
    public boolean update(CustomerEntity customer) {
         String sql = "UPDATE customer SET name=?, nic_passport=?, contact_no=?, email=?, address=?, membership=? WHERE customer_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, customer.getName());
            pst.setString(2, customer.getNicPassport());
            pst.setString(3, customer.getContactNo());
            pst.setString(4, customer.getEmail());
            pst.setString(5, customer.getAddress());
            pst.setString(6, customer.getMembership());
            pst.setInt(7, customer.getCustomerId());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int customerId) {
      String sql = "DELETE FROM customer WHERE customer_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, customerId);
            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }  
    }

    @Override
    public CustomerEntity findById(int customerId) {
        String sql = "SELECT * FROM customer WHERE customer_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, customerId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return new CustomerEntity(
                        rs.getInt("customer_id"),
                        rs.getString("customer_code"),
                        rs.getString("name"),
                        rs.getString("nic_passport"),
                        rs.getString("contact_no"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("membership")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<CustomerEntity> findAll() {
        
        String sql = "SELECT * FROM customer";
        List<CustomerEntity> list = new ArrayList<>();

        try (Connection conn = DBConnection.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                CustomerEntity customer = new CustomerEntity(
                        rs.getInt("customer_id"),
                        rs.getString("customer_code"),
                        rs.getString("name"),
                        rs.getString("nic_passport"),
                        rs.getString("contact_no"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("membership")
                );
                list.add(customer);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    }
    

