/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import lk.gearrentpro.dao.custom.BranchDao;
import lk.gearrentpro.entity.BranchEntity;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class BranchDaoImpl implements BranchDao {
    @Override
    public boolean save(BranchEntity branch) {
        String sql = "INSERT INTO branch (code, name, address, contact) VALUES (?,?,?,?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, branch.getCode());
            pst.setString(2, branch.getName());
            pst.setString(3, branch.getAddress());
            pst.setString(4, branch.getContact());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    
}
     @Override
    public boolean update(BranchEntity branch) {
        String sql = "UPDATE branch SET code=?, name=?, address=?, contact=? WHERE branch_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, branch.getCode());
            pst.setString(2, branch.getName());
            pst.setString(3, branch.getAddress());
            pst.setString(4, branch.getContact());
            pst.setInt(5, branch.getBranchId());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
     @Override
    public boolean delete(int branchId) {
        String sql = "DELETE FROM branch WHERE branch_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, branchId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    @Override
    public BranchEntity findById(int branchId) {
        String sql = "SELECT * FROM branch WHERE branch_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, branchId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return new BranchEntity(
                        rs.getInt("branch_id"),
                        rs.getString("code"),
                        rs.getString("name"),
                        rs.getString("address"),
                        rs.getString("contact")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<BranchEntity> findAll() {
        String sql = "SELECT * FROM branch";
    List<BranchEntity> branchList = new ArrayList<>();

    try (Connection conn = DBConnection.getInstance().getConnection();
         PreparedStatement pst = conn.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            branchList.add(new BranchEntity(
                    rs.getInt("branch_id"), 
                    rs.getString("code"),
                    rs.getString("name"),
                    rs.getString("address"),
                    rs.getString("contact")
            ));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return branchList;
    }
}

    
    
