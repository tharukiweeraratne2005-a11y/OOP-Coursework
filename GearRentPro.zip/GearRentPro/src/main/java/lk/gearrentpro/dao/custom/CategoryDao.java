/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;

import java.util.List;
import lk.gearrentpro.entity.CategoryEntity;

/**
 *
 * @author asus
 */
public interface CategoryDao {
    boolean save(CategoryEntity entity) throws Exception;
    boolean update(CategoryEntity entity) throws Exception;
    boolean delete(int categoryId) throws Exception;
    List<CategoryEntity> getAll() throws Exception;
    
}
