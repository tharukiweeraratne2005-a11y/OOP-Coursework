/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import lk.gearrentpro.dao.custom.ConfigDao;
import lk.gearrentpro.db.DBConnection;
import lk.gearrentpro.entity.ConfigEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author asus
 */
public class ConfigDaoImpl implements ConfigDao {
    public ConfigEntity findByKey(String cfgKey) {
        String sql = "SELECT * FROM config WHERE cfg_key=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, cfgKey);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new ConfigEntity(
                        rs.getString("cfg_key"),
                        rs.getString("cfg_value")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean save(ConfigEntity config) {
        String sql = "INSERT INTO config (cfg_key, cfg_value) VALUES (?,?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, config.getCfgKey());
            pst.setString(2, config.getCfgValue());
            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(ConfigEntity config) {
        String sql = "UPDATE config SET cfg_value=? WHERE cfg_key=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, config.getCfgValue());
            pst.setString(2, config.getCfgKey());
            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(String cfgKey) {
        String sql = "DELETE FROM config WHERE cfg_key=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, cfgKey);
            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
}
