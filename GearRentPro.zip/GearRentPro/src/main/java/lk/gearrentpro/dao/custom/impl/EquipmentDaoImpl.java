/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;

import lk.gearrentpro.dao.custom.EquipmentDao;
import lk.gearrentpro.entity.EquipmentEntity;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import lk.gearrentpro.db.DBConnection;


/**
 *
 * @author asus
 */
public class EquipmentDaoImpl implements EquipmentDao {

    @Override
    public boolean save(EquipmentEntity equipment) {
        String sql = "INSERT INTO equipment (equipment_code, category_id, brand, model, purchase_year, base_daily_price, security_deposit, status, branch_id) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, equipment.getEquipmentCode());
            pst.setInt(2, equipment.getCategoryId());
            pst.setString(3, equipment.getBrand());
            pst.setString(4, equipment.getModel());
            pst.setInt(5, equipment.getPurchaseYear());
            pst.setDouble(6, equipment.getBaseDailyPrice());
            pst.setDouble(7, equipment.getSecurityDeposit());
            pst.setString(8, equipment.getStatus());
            pst.setInt(9, equipment.getBranchId());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(EquipmentEntity equipment) {
        String sql = "UPDATE equipment SET equipment_code=?, category_id=?, brand=?, model=?, purchase_year=?, base_daily_price=?, security_deposit=?, status=?, branch_id=? "
                   + "WHERE equipment_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, equipment.getEquipmentCode());
            pst.setInt(2, equipment.getCategoryId());
            pst.setString(3, equipment.getBrand());
            pst.setString(4, equipment.getModel());
            pst.setInt(5, equipment.getPurchaseYear());
            pst.setDouble(6, equipment.getBaseDailyPrice());
            pst.setDouble(7, equipment.getSecurityDeposit());
            pst.setString(8, equipment.getStatus());
            pst.setInt(9, equipment.getBranchId());
            pst.setInt(10, equipment.getEquipmentId());

            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int equipmentId) {
        String sql = "DELETE FROM equipment WHERE equipment_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, equipmentId);
            return pst.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public EquipmentEntity findById(int equipmentId) {
        String sql = "SELECT * FROM equipment WHERE equipment_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, equipmentId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return extractEquipment(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<EquipmentEntity> findAll() {
        List<EquipmentEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM equipment";
        try (Connection conn = DBConnection.getInstance().getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(extractEquipment(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Helper method to convert ResultSet row into EquipmentEntity
    private EquipmentEntity extractEquipment(ResultSet rs) throws SQLException {
        EquipmentEntity eq = new EquipmentEntity();
        eq.setEquipmentId(rs.getInt("equipment_id"));
        eq.setEquipmentCode(rs.getString("equipment_code"));
        eq.setCategoryId(rs.getInt("category_id"));
        eq.setBrand(rs.getString("brand"));
        eq.setModel(rs.getString("model"));
        eq.setPurchaseYear(rs.getInt("purchase_year"));
        eq.setBaseDailyPrice(rs.getDouble("base_daily_price"));
        eq.setSecurityDeposit(rs.getDouble("security_deposit"));
        eq.setStatus(rs.getString("status"));
        eq.setBranchId(rs.getInt("branch_id"));
        return eq;
    }
}   