/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;

import lk.gearrentpro.dao.custom.ReservationDao;
import lk.gearrentpro.entity.ReservationEntity;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ReservationDaoImpl implements ReservationDao{

    @Override
    public boolean save(ReservationEntity entity) {
        String sql = "INSERT INTO reservation " +
                "(reservation_code, equipment_id, customer_id, branch_id, start_date, end_date, status) " +
                "VALUES (?,?,?,?,?,?,?)";

        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, entity.getReservationCode());
            pst.setInt(2, entity.getEquipmentId());
            pst.setInt(3, entity.getCustomerId());
            pst.setInt(4, entity.getBranchId());
            pst.setDate(5, new java.sql.Date(entity.getStartDate().getTime()));
            pst.setDate(6, new java.sql.Date(entity.getEndDate().getTime()));
            pst.setString(7, entity.getStatus());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(ReservationEntity entity) {
        String sql = "UPDATE reservation SET reservation_code=?, equipment_id=?, customer_id=?, " +
                "branch_id=?, start_date=?, end_date=?, status=? WHERE reservation_id=?";

        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, entity.getReservationCode());
            pst.setInt(2, entity.getEquipmentId());
            pst.setInt(3, entity.getCustomerId());
            pst.setInt(4, entity.getBranchId());
            pst.setDate(5, new java.sql.Date(entity.getStartDate().getTime()));
            pst.setDate(6, new java.sql.Date(entity.getEndDate().getTime()));
            pst.setString(7, entity.getStatus());
            pst.setInt(8, entity.getReservationId());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
       }
    }

    @Override
    public boolean delete(int reservationId) {
        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement pst =
                     con.prepareStatement("DELETE FROM reservation WHERE reservation_id=?")) {

            pst.setInt(1, reservationId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public ReservationEntity findById(int reservationId) {
        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement pst =
                     con.prepareStatement("SELECT * FROM reservation WHERE reservation_id=?")) {

            pst.setInt(1, reservationId);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) return extract(rs);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ReservationEntity> findAll() {
         List<ReservationEntity> list = new ArrayList<>();

        try (Connection con = DBConnection.getInstance().getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM reservation")) {

            while (rs.next()) list.add(extract(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    

private ReservationEntity extract(ResultSet rs) throws SQLException {
        ReservationEntity r = new ReservationEntity();
        r.setReservationId(rs.getInt("reservation_id"));
        r.setReservationCode(rs.getString("reservation_code"));
        r.setEquipmentId(rs.getInt("equipment_id"));
        r.setCustomerId(rs.getInt("customer_id"));
        r.setBranchId(rs.getInt("branch_id"));
        r.setStartDate(rs.getDate("start_date"));
        r.setEndDate(rs.getDate("end_date"));
        r.setCreatedAt(rs.getTimestamp("created_at"));
        r.setStatus(rs.getString("status"));
        return r;
    }
}
