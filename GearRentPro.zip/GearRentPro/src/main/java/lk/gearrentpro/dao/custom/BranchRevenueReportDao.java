/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import lk.gearrentpro.dto.BranchRevenueReportDto;
import java.util.Date;
import java.util.List;

/**
 *
 * @author asus
 */
public interface BranchRevenueReportDao {
    List<BranchRevenueReportDto> getRevenueReport(Date from, Date to);

}
