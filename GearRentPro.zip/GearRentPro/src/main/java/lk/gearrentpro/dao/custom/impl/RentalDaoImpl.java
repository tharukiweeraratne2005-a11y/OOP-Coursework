/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import lk.gearrentpro.dao.custom.RentalDao;
import lk.gearrentpro.entity.RentalEntity;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class RentalDaoImpl implements RentalDao {

    @Override
    public boolean save(RentalEntity rental) {
        String sql = "INSERT INTO rental (rental_code, equipment_id, customer_id, branch_id, start_date, end_date, rental_amount, security_deposit, membership_discount_pct, long_rental_discount_pct, final_payable_amount, payment_status, rental_status, actual_return_date, damage_description, damage_charge, late_fee_total) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, rental.getRentalCode());
            pst.setInt(2, rental.getEquipmentId());
            pst.setInt(3, rental.getCustomerId());
            pst.setInt(4, rental.getBranchId());
            pst.setDate(5, new java.sql.Date(rental.getStartDate().getTime()));
            pst.setDate(6, new java.sql.Date(rental.getEndDate().getTime()));
            pst.setDouble(7, rental.getRentalAmount());
            pst.setDouble(8, rental.getSecurityDeposit());
            pst.setDouble(9, rental.getMembershipDiscountPct());
            pst.setDouble(10, rental.getLongRentalDiscountPct());
            pst.setDouble(11, rental.getFinalPayableAmount());
            pst.setString(12, rental.getPaymentStatus());
            pst.setString(13, rental.getRentalStatus());
            if(rental.getActualReturnDate() != null)
                pst.setDate(14, new java.sql.Date(rental.getActualReturnDate().getTime()));
            else
                pst.setNull(14, Types.DATE);
            pst.setString(15, rental.getDamageDescription());
            pst.setDouble(16, rental.getDamageCharge());
            pst.setDouble(17, rental.getLateFeeTotal());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(RentalEntity rental) {
        String sql = "UPDATE rental SET rental_code=?, equipment_id=?, customer_id=?, branch_id=?, start_date=?, end_date=?, rental_amount=?, security_deposit=?, membership_discount_pct=?, long_rental_discount_pct=?, final_payable_amount=?, payment_status=?, rental_status=?, actual_return_date=?, damage_description=?, damage_charge=?, late_fee_total=? "
                   + "WHERE rental_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, rental.getRentalCode());
            pst.setInt(2, rental.getEquipmentId());
            pst.setInt(3, rental.getCustomerId());
            pst.setInt(4, rental.getBranchId());
            pst.setDate(5, new java.sql.Date(rental.getStartDate().getTime()));
            pst.setDate(6, new java.sql.Date(rental.getEndDate().getTime()));
            pst.setDouble(7, rental.getRentalAmount());
            pst.setDouble(8, rental.getSecurityDeposit());
            pst.setDouble(9, rental.getMembershipDiscountPct());
            pst.setDouble(10, rental.getLongRentalDiscountPct());
            pst.setDouble(11, rental.getFinalPayableAmount());
            pst.setString(12, rental.getPaymentStatus());
            pst.setString(13, rental.getRentalStatus());
            if(rental.getActualReturnDate() != null)
                pst.setDate(14, new java.sql.Date(rental.getActualReturnDate().getTime()));
            else
                pst.setNull(14, Types.DATE);
            pst.setString(15, rental.getDamageDescription());
            pst.setDouble(16, rental.getDamageCharge());
            pst.setDouble(17, rental.getLateFeeTotal());
            pst.setInt(18, rental.getRentalId());

            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(int rentalId) {
         String sql = "DELETE FROM rental WHERE rental_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, rentalId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public RentalEntity findById(int rentalId) {
        String sql = "SELECT * FROM rental WHERE rental_id=?";
        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, rentalId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return extractRental(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<RentalEntity> findAll() {
        List<RentalEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM rental";
        try (Connection conn = DBConnection.getInstance().getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(extractRental(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    private RentalEntity extractRental(ResultSet rs) throws SQLException {
        RentalEntity r = new RentalEntity();
        r.setRentalId(rs.getInt("rental_id"));
        r.setRentalCode(rs.getString("rental_code"));
        r.setEquipmentId(rs.getInt("equipment_id"));
        r.setCustomerId(rs.getInt("customer_id"));
        r.setBranchId(rs.getInt("branch_id"));
        r.setStartDate(rs.getDate("start_date"));
        r.setEndDate(rs.getDate("end_date"));
        r.setRentalAmount(rs.getDouble("rental_amount"));
        r.setSecurityDeposit(rs.getDouble("security_deposit"));
        r.setMembershipDiscountPct(rs.getDouble("membership_discount_pct"));
        r.setLongRentalDiscountPct(rs.getDouble("long_rental_discount_pct"));
        r.setFinalPayableAmount(rs.getDouble("final_payable_amount"));
        r.setPaymentStatus(rs.getString("payment_status"));
        r.setRentalStatus(rs.getString("rental_status"));
        r.setActualReturnDate(rs.getDate("actual_return_date"));
        r.setDamageDescription(rs.getString("damage_description"));
        r.setDamageCharge(rs.getDouble("damage_charge"));
        r.setLateFeeTotal(rs.getDouble("late_fee_total"));
        return r;
    }
    
}
