/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import java.util.List;
import lk.gearrentpro.entity.BranchEntity;

/**
 *
 * @author asus
 */
public interface BranchDao {
    
    boolean save(BranchEntity branch);
    boolean update(BranchEntity branch);
    boolean delete(int branchId);
    BranchEntity findById(int branchId);
    List<BranchEntity> findAll();
}
