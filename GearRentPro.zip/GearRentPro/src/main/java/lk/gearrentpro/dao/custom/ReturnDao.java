/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import lk.gearrentpro.entity.ReturnEntity;
import java.util.List;

/**
 *
 * @author asus
 */
public interface ReturnDao {
    boolean save(ReturnEntity returnEntity);
    boolean update(ReturnEntity returnEntity);
    boolean delete(int returnId);
    ReturnEntity findById(int returnId);
    List<ReturnEntity> findAll();
    
}
