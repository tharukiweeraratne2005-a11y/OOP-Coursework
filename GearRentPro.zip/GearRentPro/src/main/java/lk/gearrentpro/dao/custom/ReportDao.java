/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;

import java.util.List;
import lk.gearrentpro.entity.BranchRevenueEntity;
import lk.gearrentpro.entity.EquipmentUtilizationEntity;

/**
 *
 * @author asus
 */
public interface ReportDao {
    List<BranchRevenueEntity> getRevenueData() throws Exception;
    
    List<EquipmentUtilizationEntity> getUtilizationData() throws Exception;
    
}
