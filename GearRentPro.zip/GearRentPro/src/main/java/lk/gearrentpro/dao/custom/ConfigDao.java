/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import lk.gearrentpro.entity.ConfigEntity;
/**
 *
 * @author asus
 */
public interface ConfigDao {
    ConfigEntity findByKey(String cfgKey);
    boolean save(ConfigEntity config);
    boolean update(ConfigEntity config);
    boolean delete(String cfgKey);
}
    

