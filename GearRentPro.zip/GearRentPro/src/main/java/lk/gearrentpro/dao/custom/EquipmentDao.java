/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import java.util.List;
import lk.gearrentpro.entity.EquipmentEntity;

/**
 *
 * @author asus
 */
public interface EquipmentDao {
    boolean save(EquipmentEntity equipment);
    boolean update(EquipmentEntity equipment);
    boolean delete(int equipmentId);
    EquipmentEntity findById(int equipmentId);
    List<EquipmentEntity> findAll();
    
}
