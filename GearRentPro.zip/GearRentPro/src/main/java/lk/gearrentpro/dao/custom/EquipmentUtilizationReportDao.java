/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import java.sql.Date;
import java.util.List;
import lk.gearrentpro.dto.EquipmentUtilizationReportDto;

/**
 *
 * @author asus
 */
public interface EquipmentUtilizationReportDao {
    List<EquipmentUtilizationReportDto> getUtilizationReport(
           
            Date startDate,
            Date endDate
    );
    
}
