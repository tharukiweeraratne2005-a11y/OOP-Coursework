/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import lk.gearrentpro.entity.ReservationEntity;
import java.util.List;

/**
 *
 * @author asus
 */
public interface ReservationDao {
    boolean save(ReservationEntity entity);
    boolean update(ReservationEntity entity);
    boolean delete(int reservationId);
    ReservationEntity findById(int reservationId);
    List<ReservationEntity> findAll();
    
}
