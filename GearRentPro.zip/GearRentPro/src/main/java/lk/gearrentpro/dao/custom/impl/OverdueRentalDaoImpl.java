/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;

import lk.gearrentpro.dao.custom.OverdueRentalDao;
import lk.gearrentpro.dto.OverdueRentalDto;
import lk.gearrentpro.db.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class OverdueRentalDaoImpl implements OverdueRentalDao {

    @Override
    public List<OverdueRentalDto> findAllOverdue() {
                List<OverdueRentalDto> list = new ArrayList<>();

        String sql = """
            SELECT r.reservation_id,
                   r.reservation_code,
                   r.equipment_id,
                   r.customer_id,
                   r.branch_id,
                   r.end_date,
                   DATEDIFF(CURRENT_DATE, r.end_date) AS overdue_days,
                   DATEDIFF(CURRENT_DATE, r.end_date) * c.default_late_fee_per_day AS late_fee
            FROM reservation r
            JOIN equipment e ON r.equipment_id = e.equipment_id
            JOIN category c ON e.category_id = c.category_id
            WHERE r.end_date < CURRENT_DATE
              AND r.status = 'Active'
        """;

        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new OverdueRentalDto(
                        rs.getInt("reservation_id"),
                        rs.getString("reservation_code"),
                        rs.getInt("equipment_id"),
                        rs.getInt("customer_id"),
                        rs.getInt("branch_id"),
                        rs.getDate("end_date"),
                        rs.getInt("overdue_days"),
                        rs.getDouble("late_fee")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    }
    

