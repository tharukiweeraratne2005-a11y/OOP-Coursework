/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import lk.gearrentpro.entity.CustomerEntity;
import java.util.List;

/**
 *
 * @author asus
 */
public interface CustomerDao {
    boolean save(CustomerEntity customer);
    boolean update(CustomerEntity customer);
    boolean delete(int customerId);
    CustomerEntity findById(int customerId);
    List<CustomerEntity> findAll();
    
}
