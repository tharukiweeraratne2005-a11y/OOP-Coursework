/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import lk.gearrentpro.dao.custom.BranchRevenueReportDao;
import lk.gearrentpro.dto.BranchRevenueReportDto;
import lk.gearrentpro.db.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 *
 * @author asus
 */
public class BranchRevenueReportDaoImpl implements BranchRevenueReportDao{
    @Override
    public List<BranchRevenueReportDto> getRevenueReport(Date from, Date to) {
    List<BranchRevenueReportDto> list = new ArrayList<>();

    String sql = "SELECT b.branch_id, b.name AS branch_name, " +
                 "COUNT(r.rental_id) AS total_rentals, " +
                 "IFNULL(SUM(r.final_payable_amount), 0) AS total_income, " +
                 "IFNULL(SUM(r.late_fee_total), 0) AS total_late_fees, " +
                 "IFNULL(SUM(r.damage_charge), 0) AS total_damage_charges " +
                 "FROM branch b " +
                 "LEFT JOIN rental r ON b.branch_id = r.branch_id " +
                 "WHERE r.start_date BETWEEN ? AND ? " +
                 "GROUP BY b.branch_id, b.name";

    try (Connection conn = DBConnection.getInstance().getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setDate(1, new java.sql.Date(from.getTime()));
        pst.setDate(2, new java.sql.Date(to.getTime()));

        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            BranchRevenueReportDto dto = new BranchRevenueReportDto(
                    rs.getInt("branch_id"),
                    rs.getString("branch_name"),
                    rs.getInt("total_rentals"),
                    rs.getDouble("total_income"),
                    rs.getDouble("total_late_fees"),
                    rs.getDouble("total_damage_charges")
            );
            list.add(dto);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return list;
}
}
    

