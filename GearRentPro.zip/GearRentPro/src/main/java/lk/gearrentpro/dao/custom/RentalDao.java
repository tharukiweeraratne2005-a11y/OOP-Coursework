/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package lk.gearrentpro.dao.custom;
import lk.gearrentpro.entity.RentalEntity;
import java.util.List;

/**
 *
 * @author asus
 */
public interface RentalDao {
    boolean save(RentalEntity rental);
    boolean update(RentalEntity rental);
    boolean delete(int rentalId);
    RentalEntity findById(int rentalId);
    List<RentalEntity> findAll();
    
}
