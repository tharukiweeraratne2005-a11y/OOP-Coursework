/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import lk.gearrentpro.dao.custom.CategoryDao;
import lk.gearrentpro.entity.CategoryEntity;
import lk.gearrentpro.db.DBConnection;

/**
 *
 * @author asus
 */
public class CategoryDaoImpl implements CategoryDao {

    @Override
    public boolean save(CategoryEntity entity) throws Exception {
        String sql = """
            INSERT INTO category
            (name, description, base_price_factor, weekend_multiplier,
             default_late_fee_per_day, active)
            VALUES (?,?,?,?,?,?)
        """;

        PreparedStatement ps = DBConnection.getInstance()
                .getConnection().prepareStatement(sql);

        ps.setString(1, entity.getName());
        ps.setString(2, entity.getDescription());
        ps.setDouble(3, entity.getBasePriceFactor());
        ps.setDouble(4, entity.getWeekendMultiplier());
        ps.setDouble(5, entity.getDefaultLateFeePerDay());
        ps.setBoolean(6, entity.isActive());

        return ps.executeUpdate() > 0;
    }

    @Override
    public boolean update(CategoryEntity entity) throws Exception {
         String sql = """
            UPDATE category SET
            name=?, description=?, base_price_factor=?, weekend_multiplier=?,
            default_late_fee_per_day=?, active=?
            WHERE category_id=?
        """;

        PreparedStatement ps = DBConnection.getInstance()
                .getConnection().prepareStatement(sql);

        ps.setString(1, entity.getName());
        ps.setString(2, entity.getDescription());
        ps.setDouble(3, entity.getBasePriceFactor());
        ps.setDouble(4, entity.getWeekendMultiplier());
        ps.setDouble(5, entity.getDefaultLateFeePerDay());
        ps.setBoolean(6, entity.isActive());
        ps.setInt(7, entity.getCategoryId());

        return ps.executeUpdate() > 0;
    }

    @Override
    public boolean delete(int categoryId) throws Exception {
        PreparedStatement ps = DBConnection.getInstance()
                .getConnection()
                .prepareStatement("DELETE FROM category WHERE category_id=?");
        ps.setInt(1, categoryId);
        return ps.executeUpdate() > 0;
    }

    @Override
    public List<CategoryEntity> getAll() throws Exception {
        List<CategoryEntity> list = new ArrayList<>();

        ResultSet rs = DBConnection.getInstance()
                .getConnection()
                .createStatement()
                .executeQuery("SELECT * FROM category");

        while (rs.next()) {
            list.add(new CategoryEntity(
                    rs.getInt("category_id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("base_price_factor"),
                    rs.getDouble("weekend_multiplier"),
                    rs.getDouble("default_late_fee_per_day"),
                    rs.getBoolean("active")
            ));
        }
        return list;
    }
    
}
