/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.dao.custom.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import lk.gearrentpro.db.DBConnection; 
import lk.gearrentpro.entity.BranchRevenueEntity;
import lk.gearrentpro.entity.EquipmentUtilizationEntity;
import lk.gearrentpro.dao.custom.ReportDao;

public class ReportDaoImpl implements ReportDao {

   
    public List<BranchRevenueEntity> getRevenueData() throws Exception {
        Connection connection = DBConnection.getInstance().getConnection();
        String sql = "SELECT b.branch_id, b.name, COUNT(r.rental_id), SUM(r.final_payable_amount) " +
                     "FROM rental r " +
                     "JOIN branch b ON r.branch_id = b.branch_id " +
                     "GROUP BY b.branch_id";

        PreparedStatement pstm = connection.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();

        List<BranchRevenueEntity> list = new ArrayList<>();
        while (rs.next()) {
            list.add(new BranchRevenueEntity(
                rs.getInt(1),    // branchId
                rs.getString(2), // branchName
                rs.getInt(3),    // totalRentals
                rs.getDouble(4), // totalIncome
                0.0,             // totalLateFees
                0.0              // totalDamageCharges
            ));
        }
        return list;
    }

    
    public List<EquipmentUtilizationEntity> getUtilizationData() throws Exception {
        Connection connection = DBConnection.getInstance().getConnection();
        String sql = "SELECT e.equipment_id, e.equipment_code, e.brand, e.model, " +
                     "SUM(DATEDIFF(IFNULL(r.actual_return_date, CURDATE()), r.start_date)) AS days_rented, " +
                     "COUNT(r.rental_id) AS total_times " +
                     "FROM equipment e " +
                     "LEFT JOIN rental r ON e.equipment_id = r.equipment_id " +
                     "GROUP BY e.equipment_id";

        PreparedStatement pstm = connection.prepareStatement(sql);
        ResultSet rs = pstm.executeQuery();

        List<EquipmentUtilizationEntity> list = new ArrayList<>();
        while (rs.next()) {
            list.add(new EquipmentUtilizationEntity(
                rs.getInt(1),    // equipmentId
                rs.getString(2), // equipmentCode
                rs.getString(3), // brand
                rs.getString(4), // model
                rs.getLong(5),   // daysRented
                rs.getLong(6)    // totalTimes
            ));
        }
        return list;
    }
}