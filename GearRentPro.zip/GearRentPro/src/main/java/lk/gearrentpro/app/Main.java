/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.app;

/**
 *
 * @author asus
 */
public class Main {
    public static void main(String[] args) {
        // AppInitializer eke thiyena launch(args) eka meken trigger wenawa
        AppInitializer.main(args);
    }
    
}
