/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;
import java.util.List;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import lk.gearrentpro.dto.EquipmentDto;
import lk.gearrentpro.service.custom.EquipmentService;
import lk.gearrentpro.service.custom.impl.EquipmentServiceImpl;





/**
 *
 * @author asus
 */
public class EquipmentController {
     
private final EquipmentService equipmentService = new EquipmentServiceImpl();

    // -------------------- TextFields --------------------
    @FXML private TextField txtEquipmentId;
    @FXML private TextField txtEquipmentCode;
    @FXML private ComboBox<String> cmbCategory; 
    @FXML private ComboBox<String> cmbBranch; 
    @FXML private TextField txtBrand;
    @FXML private TextField txtModel;
    @FXML private TextField txtPurchaseYear;
    @FXML private TextField txtBaseDailyPrice;
    @FXML private TextField txtSecurityDeposit;

    // -------------------- ComboBox --------------------
    @FXML private ComboBox<String> cmbStatus;

    // -------------------- Table --------------------
    @FXML private TableView<EquipmentDto> tblEquipment;
    @FXML private TableColumn<EquipmentDto, Integer> colId;
    @FXML private TableColumn<EquipmentDto, String> colCode;
    @FXML private TableColumn<EquipmentDto, Integer> colCategory;
    @FXML private TableColumn<EquipmentDto, String> colBrand;
    @FXML private TableColumn<EquipmentDto, String> colModel;
    @FXML private TableColumn<EquipmentDto, String> colStatus;
    @FXML private TableColumn<EquipmentDto, Integer> colBranch;

    // -------------------- Initialize --------------------
    @FXML
    public void initialize() {
    colId.setCellValueFactory(new PropertyValueFactory<>("equipmentId"));
    colCode.setCellValueFactory(new PropertyValueFactory<>("equipmentCode"));
    colCategory.setCellValueFactory(new PropertyValueFactory<>("categoryId"));
    colBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));
    colModel.setCellValueFactory(new PropertyValueFactory<>("model"));
    colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
    colBranch.setCellValueFactory(new PropertyValueFactory<>("branchId"));

    cmbStatus.setItems(FXCollections.observableArrayList("Available", "Reserved", "Rented", "Under Maintenance"));
    cmbCategory.setItems(FXCollections.observableArrayList("1", "2", "3", "4", "5"));
    cmbBranch.setItems(FXCollections.observableArrayList("1", "2", "3"));

    loadTable();
    
    tableListener();
}

    // -------------------- Load Table --------------------
    private void loadTable() {
    try {
        List<EquipmentDto> list = equipmentService.getAllEquipment();
        
        ObservableList<EquipmentDto> obList = FXCollections.observableArrayList(list);
        
        tblEquipment.setItems(obList);
        
        System.out.println("Data loaded: " + list.size() + " items found.");
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    // -------------------- Table Click --------------------
    private void tableListener() {
        tblEquipment.getSelectionModel().selectedItemProperty()
                .addListener((obs, oldVal, newVal) -> {
                    if (newVal != null) {
                        txtEquipmentId.setText(String.valueOf(newVal.getEquipmentId()));
                        txtEquipmentCode.setText(newVal.getEquipmentCode());
                        cmbCategory.setValue(String.valueOf(newVal.getCategoryId()));
                        cmbBranch.setValue(String.valueOf(newVal.getBranchId()));                        txtBrand.setText(newVal.getBrand());
                        txtModel.setText(newVal.getModel());
                        txtPurchaseYear.setText(String.valueOf(newVal.getPurchaseYear()));
                        txtBaseDailyPrice.setText(String.valueOf(newVal.getBaseDailyPrice()));
                        txtSecurityDeposit.setText(String.valueOf(newVal.getSecurityDeposit()));
                        cmbStatus.setValue(newVal.getStatus());
                    }
                });
    }

    // -------------------- Save --------------------
    @FXML
    void btnSaveOnAction(ActionEvent event) {

       
    String categoryIdStr = cmbCategory.getValue();
    String branchIdStr = cmbBranch.getValue();

   
    if (categoryIdStr == null || branchIdStr == null) {
        new Alert(Alert.AlertType.WARNING, "Please select Category and Branch").show();
        return;
    }

    EquipmentDto dto = new EquipmentDto(
            txtEquipmentCode.getText(),
            Integer.parseInt(categoryIdStr), 
            txtBrand.getText(),
            txtModel.getText(),
            Integer.parseInt(txtPurchaseYear.getText()),
            Double.parseDouble(txtBaseDailyPrice.getText()),
            Double.parseDouble(txtSecurityDeposit.getText()),
            cmbStatus.getValue(),
            Integer.parseInt(branchIdStr)
    );

        if (equipmentService.saveEquipment(dto)) {
            new Alert(Alert.AlertType.INFORMATION, "Equipment Saved Successfully").show();
            clearFields();
            loadTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Save Failed").show();
        }
    }

    // -------------------- Update --------------------
    @FXML
    void btnUpdateOnAction(ActionEvent event) {
        String categoryId = cmbCategory.getValue();
        String branchId = cmbBranch.getValue();

    if (categoryId == null || branchId == null) {
        new Alert(Alert.AlertType.WARNING, "Please select Category and Branch").show();
        return;
    }

        EquipmentDto dto = new EquipmentDto(
                Integer.parseInt(txtEquipmentId.getText()),
                txtEquipmentCode.getText(),
                Integer.parseInt(categoryId),                
                txtBrand.getText(),
                txtModel.getText(),
                Integer.parseInt(txtPurchaseYear.getText()),
                Double.parseDouble(txtBaseDailyPrice.getText()),
                Double.parseDouble(txtSecurityDeposit.getText()),
                cmbStatus.getValue(),
                Integer.parseInt(branchId)       
        );

        if (equipmentService.updateEquipment(dto)) {
            new Alert(Alert.AlertType.INFORMATION, "Equipment Updated").show();
            clearFields();
            loadTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Update Failed").show();
        }
    }

    // -------------------- Delete --------------------
    @FXML
    void btnDeleteOnAction(ActionEvent event) {
        
        
        if (equipmentService.deleteEquipment(Integer.parseInt(txtEquipmentId.getText()))) {
            new Alert(Alert.AlertType.INFORMATION, "Equipment Deleted").show();
            clearFields();
            loadTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Delete Failed").show();
        }
    }

    // -------------------- Clear --------------------
    @FXML
    void btnClearOnAction(ActionEvent event) {
        clearFields();
    }

    private void clearFields() {
        txtEquipmentId.clear();
        txtEquipmentCode.clear();
        cmbCategory.setValue(null); 
        cmbBranch.setValue(null);
        txtBrand.clear();
        txtModel.clear();
        txtPurchaseYear.clear();
        txtBaseDailyPrice.clear();
        txtSecurityDeposit.clear();
        cmbStatus.setValue(null);
        tblEquipment.getSelectionModel().clearSelection();
    }
}