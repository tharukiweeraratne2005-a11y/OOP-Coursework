/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;

import lk.gearrentpro.dto.ReservationDto;
import lk.gearrentpro.service.custom.ReservationService;
import lk.gearrentpro.service.custom.impl.ReservationServiceImpl;

import java.util.List;

/**
 *
 * @author asus
 */
public class ReservationController {
    private final ReservationService service = new ReservationServiceImpl();

    @FXML private TextField txtReservationId;
    @FXML private TextField txtReservationCode;
    @FXML private TextField txtEquipmentId;
    @FXML private TextField txtCustomerId;
    @FXML private TextField txtBranchId;
    @FXML private DatePicker dpStartDate;
    @FXML private DatePicker dpEndDate;
    @FXML private ComboBox<String> cmbStatus;

    @FXML private TableView<ReservationDto> tblReservation;
    @FXML private TableColumn<ReservationDto, Integer> colId;
    @FXML private TableColumn<ReservationDto, String> colCode;
    @FXML private TableColumn<ReservationDto, Integer> colEquipment;
    @FXML private TableColumn<ReservationDto, Integer> colCustomer;
    @FXML private TableColumn<ReservationDto, String> colStatus;

    @FXML
    public void initialize() {

        colId.setCellValueFactory(new PropertyValueFactory<>("reservationId"));
        colCode.setCellValueFactory(new PropertyValueFactory<>("reservationCode"));
        colEquipment.setCellValueFactory(new PropertyValueFactory<>("equipmentId"));
        colCustomer.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        cmbStatus.setItems(FXCollections.observableArrayList(
                "Active", "Cancelled", "Converted"
        ));

        loadTable();
        tableListener();
    }

    private void loadTable() {
        List<ReservationDto> list = service.getAllReservations();
        ObservableList<ReservationDto> ob = FXCollections.observableArrayList(list);
        tblReservation.setItems(ob);
    }

    private void tableListener() {
        tblReservation.getSelectionModel().selectedItemProperty()
                .addListener((o, ov, r) -> {
                    if (r != null) {
                        txtReservationId.setText(String.valueOf(r.getReservationId()));
                        txtReservationCode.setText(r.getReservationCode());
                        txtEquipmentId.setText(String.valueOf(r.getEquipmentId()));
                        txtCustomerId.setText(String.valueOf(r.getCustomerId()));
                        txtBranchId.setText(String.valueOf(r.getBranchId()));

                        dpStartDate.setValue(
                                new java.sql.Date(r.getStartDate().getTime()).toLocalDate()
                        );
                        dpEndDate.setValue(
                                new java.sql.Date(r.getEndDate().getTime()).toLocalDate()
                        );

                        cmbStatus.setValue(r.getStatus());
                    }
                });
    }

    @FXML
    void btnSaveOnAction(ActionEvent e) {
        service.saveReservation(new ReservationDto(
                txtReservationCode.getText(),
                Integer.parseInt(txtEquipmentId.getText()),
                Integer.parseInt(txtCustomerId.getText()),
                Integer.parseInt(txtBranchId.getText()),
                java.sql.Date.valueOf(dpStartDate.getValue()),
                java.sql.Date.valueOf(dpEndDate.getValue()),
                cmbStatus.getValue()
        ));
        loadTable();
    }

    @FXML
    void btnUpdateOnAction(ActionEvent e) {
        service.updateReservation(new ReservationDto(
                Integer.parseInt(txtReservationId.getText()),
                txtReservationCode.getText(),
                Integer.parseInt(txtEquipmentId.getText()),
                Integer.parseInt(txtCustomerId.getText()),
                Integer.parseInt(txtBranchId.getText()),
                java.sql.Date.valueOf(dpStartDate.getValue()),
                java.sql.Date.valueOf(dpEndDate.getValue()),
                cmbStatus.getValue()
        ));
        loadTable();
    }

    @FXML
    void btnDeleteOnAction(ActionEvent e) {
        
        service.deleteReservation(Integer.parseInt(txtReservationId.getText()));
        loadTable();
    }
    
}
