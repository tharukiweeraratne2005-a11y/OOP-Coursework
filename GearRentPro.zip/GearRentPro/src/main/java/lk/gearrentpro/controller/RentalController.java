/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import lk.gearrentpro.dto.RentalDto;
import lk.gearrentpro.service.custom.RentalService;
import lk.gearrentpro.service.custom.impl.RentalServiceImpl;

/**
 *
 * @author asus
 */
public class RentalController {
    private final RentalService rentalService = new RentalServiceImpl();

    // -------------------- Fields --------------------
    @FXML private TextField txtRentalId;
    @FXML private TextField txtRentalCode;
    @FXML private TextField txtEquipmentId;
    @FXML private TextField txtCustomerId;
    @FXML private TextField txtBranchId;
    @FXML private DatePicker dpStartDate;
    @FXML private DatePicker dpEndDate;
    @FXML private TextField txtRentalAmount;
    @FXML private TextField txtSecurityDeposit;
    @FXML private ComboBox<String> cmbPaymentStatus;
    @FXML private ComboBox<String> cmbRentalStatus;

    // -------------------- Table --------------------
    @FXML private TableView<RentalDto> tblRental;
    @FXML private TableColumn<RentalDto, Integer> colId;
    @FXML private TableColumn<RentalDto, String> colCode;
    @FXML private TableColumn<RentalDto, Integer> colEquipmentId;
    @FXML private TableColumn<RentalDto, Integer> colCustomerId;
    @FXML private TableColumn<RentalDto, String> colStatus;

    @FXML
    public void initialize() {

        colId.setCellValueFactory(new PropertyValueFactory<>("rentalId"));
        colCode.setCellValueFactory(new PropertyValueFactory<>("rentalCode"));
        colEquipmentId.setCellValueFactory(new PropertyValueFactory<>("equipmentId"));
        colCustomerId.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("rentalStatus"));

        cmbPaymentStatus.setItems(FXCollections.observableArrayList(
                "Paid", "Partially Paid", "Unpaid"
        ));

        cmbRentalStatus.setItems(FXCollections.observableArrayList(
                "Active", "Returned", "Overdue", "Cancelled"
        ));

        loadTable();
        tableListener();
    }

    private void loadTable() {
        List<RentalDto> list = rentalService.getAllRentals();
        ObservableList<RentalDto> obList = FXCollections.observableArrayList(list);
        tblRental.setItems(obList);
    }

    private void tableListener() {
        tblRental.getSelectionModel().selectedItemProperty()
                .addListener((obs, oldVal, r) -> {
                    if (r != null) {
                        txtRentalId.setText(String.valueOf(r.getRentalId()));
                        txtRentalCode.setText(r.getRentalCode());
                        txtEquipmentId.setText(String.valueOf(r.getEquipmentId()));
                        txtCustomerId.setText(String.valueOf(r.getCustomerId()));
                        txtBranchId.setText(String.valueOf(r.getBranchId()));
                        dpStartDate.setValue(
                              new java.sql.Date(r.getStartDate().getTime()).toLocalDate()
                        );

                        dpEndDate.setValue(
                              new java.sql.Date(r.getEndDate().getTime()).toLocalDate()
                        );

                        txtRentalAmount.setText(String.valueOf(r.getRentalAmount()));
                        txtSecurityDeposit.setText(String.valueOf(r.getSecurityDeposit()));
                        cmbPaymentStatus.setValue(r.getPaymentStatus());
                        cmbRentalStatus.setValue(r.getRentalStatus());
                    }
                });
    }

    // -------------------- Save --------------------
    @FXML
    void btnSaveOnAction(ActionEvent event) {

        RentalDto dto = new RentalDto(
                0,
                txtRentalCode.getText(),
                Integer.parseInt(txtEquipmentId.getText()),
                Integer.parseInt(txtCustomerId.getText()),
                Integer.parseInt(txtBranchId.getText()),
                java.sql.Date.valueOf(dpStartDate.getValue()),
                java.sql.Date.valueOf(dpEndDate.getValue()),
                Double.parseDouble(txtRentalAmount.getText()),
                Double.parseDouble(txtSecurityDeposit.getText()),
                0,
                0,
                Double.parseDouble(txtRentalAmount.getText()),
                cmbPaymentStatus.getValue(),
                cmbRentalStatus.getValue(),
                null,
                null,
                0,
                0
        );

        if (rentalService.saveRental(dto)) {
            alert("Rental saved");
            clear();
            loadTable();
        }
    }

    // -------------------- Delete --------------------
    @FXML
    void btnDeleteOnAction(ActionEvent event) {
        
        if (rentalService.deleteRental(Integer.parseInt(txtRentalId.getText()))) {
            alert("Rental deleted");
            clear();
            loadTable();
        }
    }
    @FXML
    
void btnUpdateOnAction(ActionEvent event) {
    try {
        int id = Integer.parseInt(txtRentalId.getText());
        String code = txtRentalCode.getText();
        int eqId = Integer.parseInt(txtEquipmentId.getText());
        int cusId = Integer.parseInt(txtCustomerId.getText());
        int brId = Integer.parseInt(txtBranchId.getText());
        java.sql.Date start = java.sql.Date.valueOf(dpStartDate.getValue());
        java.sql.Date end = java.sql.Date.valueOf(dpEndDate.getValue());
        double amount = Double.parseDouble(txtRentalAmount.getText());
        double deposit = Double.parseDouble(txtSecurityDeposit.getText());
        String payStatus = cmbPaymentStatus.getValue();
        String rentStatus = cmbRentalStatus.getValue();

        RentalDto rentalDto = new RentalDto(
                id, code, eqId, cusId, brId, start, end,
                amount, deposit, 0, 0, amount, payStatus, rentStatus,
                null, null, 0, 0
        );

        boolean isUpdated = rentalService.updateRental(rentalDto);

        if (isUpdated) {
            new Alert(Alert.AlertType.INFORMATION, "Updated Successfully!").show();
            loadTable(); 
            clear();
        } else {
            new Alert(Alert.AlertType.ERROR, "Update Failed!").show();
        }
    } catch (Exception e) {
        new Alert(Alert.AlertType.ERROR, "Error: " + e.getMessage()).show();
    }
}

    private void clear() {
        txtRentalId.clear();
        txtRentalCode.clear();
        txtEquipmentId.clear();
        txtCustomerId.clear();
        txtBranchId.clear();
        txtRentalAmount.clear();
        txtSecurityDeposit.clear();
        dpStartDate.setValue(null);
        dpEndDate.setValue(null);
        cmbPaymentStatus.setValue(null);
        cmbRentalStatus.setValue(null);
        tblRental.getSelectionModel().clearSelection();
    }

    private void alert(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).show();
    }
    
}
