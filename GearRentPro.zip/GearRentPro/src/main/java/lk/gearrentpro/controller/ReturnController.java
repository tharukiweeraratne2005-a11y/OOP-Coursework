/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.gearrentpro.dto.ReturnDto;
import lk.gearrentpro.service.custom.ReturnService;
import lk.gearrentpro.service.custom.impl.ReturnServiceImpl;
import java.util.List;

/**
 *
 * @author asus
 */
public class ReturnController {
    private final ReturnService returnService = new ReturnServiceImpl();

    @FXML private TextField txtReturnId;
    @FXML private TextField txtRentalId;
    @FXML private TextField txtEquipmentId;
    @FXML private TextField txtCustomerId;
    @FXML private DatePicker dpReturnDate;
    @FXML private TextField txtDamageCharge;
    @FXML private TextField txtLateFee;

    @FXML private TableView<ReturnDto> tblReturn;
    @FXML private TableColumn<ReturnDto, Integer> colId;
    @FXML private TableColumn<ReturnDto, Integer> colRentalId;
    @FXML private TableColumn<ReturnDto, Integer> colEquipmentId;
    @FXML private TableColumn<ReturnDto, Integer> colCustomerId;
    @FXML private TableColumn<ReturnDto, String> colReturnDate;
    @FXML private TableColumn<ReturnDto, Double> colDamageCharge;
    @FXML private TableColumn<ReturnDto, Double> colLateFee;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("returnId"));
        colRentalId.setCellValueFactory(new PropertyValueFactory<>("rentalId"));
        colEquipmentId.setCellValueFactory(new PropertyValueFactory<>("equipmentId"));
        colCustomerId.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        colReturnDate.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        colDamageCharge.setCellValueFactory(new PropertyValueFactory<>("damageCharge"));
        colLateFee.setCellValueFactory(new PropertyValueFactory<>("lateFee"));

        loadTable();
        tableListener();
    }

    private void loadTable() {
        List<ReturnDto> list = returnService.getAllReturns();
        ObservableList<ReturnDto> obList = FXCollections.observableArrayList(list);
        tblReturn.setItems(obList);
    }

    private void tableListener() {
        tblReturn.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, r) -> {
            if (r != null) {
                txtReturnId.setText(String.valueOf(r.getReturnId()));
                txtRentalId.setText(String.valueOf(r.getRentalId()));
                txtEquipmentId.setText(String.valueOf(r.getEquipmentId()));
                txtCustomerId.setText(String.valueOf(r.getCustomerId()));
                dpReturnDate.setValue(new java.sql.Date(r.getReturnDate().getTime()).toLocalDate());
                txtDamageCharge.setText(String.valueOf(r.getDamageCharge()));
                txtLateFee.setText(String.valueOf(r.getLateFee()));
            }
        });
    }

    @FXML
void btnSaveOnAction(ActionEvent event) {
    try {
        int returnId = Integer.parseInt(txtReturnId.getText());
        int rentalId = Integer.parseInt(txtRentalId.getText());

        ReturnDto dto = new ReturnDto(
                returnId, 
                rentalId,
                Integer.parseInt(txtEquipmentId.getText()),
                Integer.parseInt(txtCustomerId.getText()),
                java.sql.Date.valueOf(dpReturnDate.getValue()),
                Double.parseDouble(txtDamageCharge.getText()),
                Double.parseDouble(txtLateFee.getText())
        );

        if (returnService.saveReturn(dto)) {
            alert("Return saved successfully!");
            clear();
            loadTable();
        } else {
            alert("Save Failed! Please check your data.");
        }
    } catch (NumberFormatException e) {
        alert("Please enter valid numbers for IDs and Charges!");
    } catch (Exception e) {
        
        alert("Error: " + e.getMessage());
    }
}

@FXML
void btnUpdateOnAction(ActionEvent event) {
    try {
       
        ReturnDto dto = new ReturnDto(
                Integer.parseInt(txtReturnId.getText()), 
                Integer.parseInt(txtRentalId.getText()),
                Integer.parseInt(txtEquipmentId.getText()),
                Integer.parseInt(txtCustomerId.getText()),
                java.sql.Date.valueOf(dpReturnDate.getValue()),
                Double.parseDouble(txtDamageCharge.getText()),
                Double.parseDouble(txtLateFee.getText())
        );

        if (returnService.updateReturn(dto)) {
            alert("Return updated successfully!");
            clear();
            loadTable();
        } else {
            alert("Update Failed! Record not found.");
        }
    } catch (Exception e) {
        alert("Update Error: " + e.getMessage());
    }
}

    @FXML
    void btnDeleteOnAction(ActionEvent event) {
            if (returnService.deleteReturn(Integer.parseInt(txtReturnId.getText()))) {
            alert("Return deleted");
            clear();
            loadTable();
        }
    }

    private void clear() {
        txtReturnId.clear();
        txtRentalId.clear();
        txtEquipmentId.clear();
        txtCustomerId.clear();
        dpReturnDate.setValue(null);
        txtDamageCharge.clear();
        txtLateFee.clear();
        tblReturn.getSelectionModel().clearSelection();
    }

    private void alert(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).show();
    }
    
}
