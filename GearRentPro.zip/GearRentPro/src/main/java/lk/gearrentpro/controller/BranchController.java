/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import lk.gearrentpro.dto.BranchDto;
import lk.gearrentpro.service.custom.BranchService;
import lk.gearrentpro.service.custom.impl.BranchServiceImpl;


/**
 *
 * @author asus
 */
public class BranchController {
     // -------------------- Service --------------------
    private final BranchService branchService = new BranchServiceImpl();

    // -------------------- TextFields --------------------
    @FXML
    private TextField txtBranchId;

    @FXML
    private TextField txtCode;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtAddress;

    @FXML
    private TextField txtContact;

    // -------------------- Table --------------------
    @FXML
    private TableView<BranchDto> tblBranch;

    @FXML
    private TableColumn<BranchDto, Integer> colId;

    @FXML
    private TableColumn<BranchDto, String> colCode;

    @FXML
    private TableColumn<BranchDto, String> colName;

    @FXML
    private TableColumn<BranchDto, String> colAddress;

    @FXML
    private TableColumn<BranchDto, String> colContact;

    // -------------------- Initialize --------------------
    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("branchId"));
        colCode.setCellValueFactory(new PropertyValueFactory<>("code"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        colContact.setCellValueFactory(new PropertyValueFactory<>("contact"));

        loadTable();
        tableListener();
    }

    // -------------------- Load Table --------------------
    private void loadTable() {
        List<BranchDto> list = branchService.getAllBranches();
        ObservableList<BranchDto> obList = FXCollections.observableArrayList(list);
        tblBranch.setItems(obList);
    }

    // -------------------- Table Click --------------------
    private void tableListener() {
        tblBranch.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                txtBranchId.setText(String.valueOf(newVal.getBranchId()));
                txtCode.setText(newVal.getCode());
                txtName.setText(newVal.getName());
                txtAddress.setText(newVal.getAddress());
                txtContact.setText(newVal.getContact());
            }
        });
    }

    // -------------------- Save --------------------
    @FXML
    void btnSaveOnAction(ActionEvent event) {

        BranchDto dto = new BranchDto(
                txtCode.getText(),
                txtName.getText(),
                txtAddress.getText(),
                txtContact.getText()
        );

        boolean isSaved = branchService.saveBranch(dto);

        if (isSaved) {
            new Alert(Alert.AlertType.INFORMATION, "Branch Saved Successfully").show();
            clearFields();
            loadTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Save Failed").show();
        }
    }

    // -------------------- Update --------------------
    @FXML
    void btnUpdateOnAction(ActionEvent event) {

        BranchDto dto = new BranchDto(
                Integer.parseInt(txtBranchId.getText()),
                txtCode.getText(),
                txtName.getText(),
                txtAddress.getText(),
                txtContact.getText()
        );

        boolean isUpdated = branchService.updateBranch(dto);

        if (isUpdated) {
            new Alert(Alert.AlertType.INFORMATION, "Branch Updated").show();
            clearFields();
            loadTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Update Failed").show();
        }
    }

    // -------------------- Delete --------------------
    @FXML
    void btnDeleteOnAction(ActionEvent event) {

        int branchId = Integer.parseInt(txtBranchId.getText());
        
        boolean isDeleted = branchService.deleteBranch(branchId);

        if (isDeleted) {
            new Alert(Alert.AlertType.INFORMATION, "Branch Deleted").show();
            clearFields();
            loadTable();
        } else {
            new Alert(Alert.AlertType.ERROR, "Delete Failed").show();
        }
    }

    // -------------------- Clear --------------------
    private void clearFields() {
        txtBranchId.clear();
        txtCode.clear();
        txtName.clear();
        txtAddress.clear();
        txtContact.clear();
        tblBranch.getSelectionModel().clearSelection();
    }
}
    

