/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.gearrentpro.dto.CustomerDto;
import lk.gearrentpro.service.custom.CustomerService;
import lk.gearrentpro.service.custom.impl.CustomerServiceImpl;

/**
 * @author asus
 */
public class CustomerController { 

    private final CustomerService customerService = new CustomerServiceImpl();

    @FXML private TextField txtCustomerId;
    @FXML private TextField txtCustomerCode;
    @FXML private TextField txtName;
    @FXML private TextField txtNicPassport;
    @FXML private TextField txtContactNo;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAddress;
    @FXML private TextField txtMembership;

    // -------- TableView --------
    @FXML private TableView<CustomerDto> tblCustomer;
    @FXML private TableColumn<CustomerDto, Integer> colId;
    @FXML private TableColumn<CustomerDto, String> colCode;
    @FXML private TableColumn<CustomerDto, String> colName;
    @FXML private TableColumn<CustomerDto, String> colContact;
    @FXML private TableColumn<CustomerDto, String> colEmail;

    // -------- Initialize (Simple Way) --------
    @FXML
    public void initialize() { 
        setCellValueFactory();
        loadAllCustomers();
        tableListener();
    }

    private void setCellValueFactory() {
        colId.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        colCode.setCellValueFactory(new PropertyValueFactory<>("customerCode"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colContact.setCellValueFactory(new PropertyValueFactory<>("contactNo"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
    }

    // -------- Load Data --------
    private void loadAllCustomers() {
        try {
            List<CustomerDto> all = customerService.getAllCustomers();
            ObservableList<CustomerDto> list = FXCollections.observableArrayList(all);
            tblCustomer.setItems(list);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // -------- Table Selection --------
    private void tableListener() {
        tblCustomer.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldVal, newVal) -> {
                    if (newVal != null) {
                        txtCustomerId.setText(String.valueOf(newVal.getCustomerId()));
                        txtCustomerCode.setText(newVal.getCustomerCode());
                        txtName.setText(newVal.getName());
                        txtNicPassport.setText(newVal.getNicPassport());
                        txtContactNo.setText(newVal.getContactNo());
                        txtEmail.setText(newVal.getEmail());
                        txtAddress.setText(newVal.getAddress());
                        txtMembership.setText(newVal.getMembership());
                    }
                }
        );
    }

    // -------- Save --------
    @FXML
    void btnSaveOnAction(ActionEvent event) {
        CustomerDto dto = new CustomerDto(
               
                txtCustomerCode.getText(),
                txtName.getText(),
                txtNicPassport.getText(),
                txtContactNo.getText(),
                txtEmail.getText(),
                txtAddress.getText(),
                txtMembership.getText()
        );

        if (customerService.saveCustomer(dto)) {
            showAlert(Alert.AlertType.INFORMATION, "Customer saved successfully");
            clearFields();
            loadAllCustomers();
        } else {
            showAlert(Alert.AlertType.ERROR, "Failed to save customer");
        }
    }

    // -------- Update --------
   @FXML
   void btnUpdateOnAction(ActionEvent event) {
     try {
        if (txtCustomerId.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Please select a customer first!");
            return;
        }

        CustomerDto dto = new CustomerDto(
                Integer.parseInt(txtCustomerId.getText()), 
                txtCustomerCode.getText(),
                txtName.getText(),
                txtNicPassport.getText(),
                txtContactNo.getText(),
                txtEmail.getText(),
                txtAddress.getText(),
                txtMembership.getText()
        );

        if (customerService.updateCustomer(dto)) {
            showAlert(Alert.AlertType.INFORMATION, "Customer updated successfully");
            clearFields();
            loadAllCustomers();
        } else {
            showAlert(Alert.AlertType.ERROR, "Failed to update customer");
        }
    } catch (Exception e) {
        showAlert(Alert.AlertType.ERROR, "Error: " + e.getMessage());
    }
   }

    // -------- Delete --------
    @FXML
    void btnDeleteOnAction(ActionEvent event) {
     try {
        if (txtCustomerId.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Please select a customer to delete!");
            return;
        }

        int id = Integer.parseInt(txtCustomerId.getText());
        if (customerService.deleteCustomer(id)) {
            showAlert(Alert.AlertType.INFORMATION, "Customer deleted successfully");
            clearFields();
            loadAllCustomers();
        } else {
            showAlert(Alert.AlertType.ERROR, "Failed to delete customer");
        }
    } catch (Exception e) {
        showAlert(Alert.AlertType.ERROR, "Invalid ID found!");
    }   
        
       
    }

    // -------- Utility --------
    private void clearFields() {
        txtCustomerId.clear();
        txtCustomerCode.clear();
        txtName.clear();
        txtNicPassport.clear();
        txtContactNo.clear();
        txtEmail.clear();
        txtAddress.clear();
        txtMembership.clear();
    }

    private void showAlert(Alert.AlertType type, String msg) {
        new Alert(type, msg).show();
    }
}