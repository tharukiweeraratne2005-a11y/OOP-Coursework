/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.gearrentpro.dto.UserDto;
import lk.gearrentpro.service.custom.UserService;
import lk.gearrentpro.service.custom.impl.UserServiceImpl;
import java.util.List;

public class UserController {
    private final UserService service = new UserServiceImpl();

    @FXML private TextField txtUserId;
    @FXML private TextField txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private ComboBox<String> cmbRole;
    @FXML private TextField txtBranchId;
    @FXML private TextField txtFullName;

    @FXML private TableView<UserDto> tblUser;
    
    @FXML private TableColumn<UserDto, Integer> colId;
    @FXML private TableColumn<UserDto, String> colFullName;
    @FXML private TableColumn<UserDto, String> colUsername;
    @FXML private TableColumn<UserDto, String> colRole;
    @FXML private TableColumn<UserDto, Integer> colBranch;

    @FXML
    public void initialize() {
        cmbRole.setItems(FXCollections.observableArrayList(
                "Admin", "BranchManager", "Staff"
        ));

        colId.setCellValueFactory(new PropertyValueFactory<>("userId"));
        colFullName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colBranch.setCellValueFactory(new PropertyValueFactory<>("branchId"));

        loadTable();
        addTableListener();
    }

    @FXML
    void btnSave() {
        try {
            UserDto dto = new UserDto(
                    txtUsername.getText(),
                    txtPassword.getText(),
                    cmbRole.getValue(),
                    txtBranchId.getText().isEmpty() ? null : Integer.parseInt(txtBranchId.getText()),
                    txtFullName.getText()
            );

            if (service.saveUser(dto)) {
                new Alert(Alert.AlertType.INFORMATION, "User Saved!").show();
                clearFields();
                loadTable(); 
            } else {
                new Alert(Alert.AlertType.ERROR, "Save Failed!").show();
            }
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error: " + e.getMessage()).show();
        }
    }

    private void loadTable() {
        try {
        List<UserDto> allUsers = service.getAllUsers();
        
        
        if (allUsers == null || allUsers.isEmpty()) {
            System.out.println("Warning: No users found in Database!");
        } else {
            System.out.println("Success: Found " + allUsers.size() + " users.");
            ObservableList<UserDto> obList = FXCollections.observableArrayList(allUsers);
            tblUser.setItems(obList);
        }
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
        e.printStackTrace();
    }
}
    
    private void addTableListener() {
    tblUser.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue != null) {
            setDataToTextFields(newValue); 
        }
    });
}

private void setDataToTextFields(UserDto dto) {
    txtUserId.setText(String.valueOf(dto.getUserId())); 
    txtFullName.setText(dto.getFullName());
    txtUsername.setText(dto.getUsername());
    cmbRole.setValue(dto.getRole()); 
    
    if (dto.getBranchId() != null) {
        txtBranchId.setText(String.valueOf(dto.getBranchId()));
    } else {
        txtBranchId.clear();
    }
    
    txtPassword.clear(); 
}   

   @FXML
void btnUpdate() {
    try {
        UserDto dto = new UserDto(
                txtUsername.getText(),
                txtPassword.getText(),
                cmbRole.getValue(),
                txtBranchId.getText().isEmpty() ? null : Integer.parseInt(txtBranchId.getText()),
                txtFullName.getText()
        );
        dto.setUserId(Integer.parseInt(txtUserId.getText()));

        if (service.updateUser(dto)) {
            new Alert(Alert.AlertType.INFORMATION, "User Updated!").show();
            clearFields();
            loadTable(); 
        } else {
            new Alert(Alert.AlertType.ERROR, "Update Failed!").show();
        }
    } catch (Exception e) {
        new Alert(Alert.AlertType.ERROR, "Error: " + e.getMessage()).show();
    }
}


    @FXML
    void btnDelete() {
    try {
        int userId = Integer.parseInt(txtUserId.getText());
        
        if (service.deleteUser(userId)) {
            new Alert(Alert.AlertType.INFORMATION, "User Deleted!").show();
            clearFields(); 
            loadTable();  
        } else {
            new Alert(Alert.AlertType.ERROR, "Delete Failed!").show();
        }
    } catch (Exception e) {
           new Alert(Alert.AlertType.ERROR, "Please select a user first!").show();
    }
    }
    private void clearFields() {
        txtUserId.clear();
        txtFullName.clear();
        txtUsername.clear();
        txtPassword.clear();
        txtBranchId.clear();
        cmbRole.getSelectionModel().clearSelection();
    }
}