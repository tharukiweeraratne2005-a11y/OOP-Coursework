/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.gearrentpro.dto.CategoryDto;
import lk.gearrentpro.service.custom.CategoryService;
import lk.gearrentpro.service.custom.impl.CategoryServiceImpl;

public class CategoryController {

    @FXML private TextField txtId;
    @FXML private TextField txtName;
    @FXML private TextArea txtDescription;
    @FXML private TextField txtBaseFactor;
    @FXML private TextField txtWeekendMultiplier;
    @FXML private TextField txtLateFee;
    @FXML private CheckBox chkActive;

    @FXML private TableView<CategoryDto> tblCategory;
    @FXML private TableColumn<CategoryDto, Integer> colId;
    @FXML private TableColumn<CategoryDto, String> colName;
    @FXML private TableColumn<CategoryDto, Double> colBasePriceFactor;
    @FXML private TableColumn<CategoryDto, Double> colWeekendMultiplier;

    private final CategoryService service = new CategoryServiceImpl();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("categoryId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colBasePriceFactor.setCellValueFactory(new PropertyValueFactory<>("basePriceFactor"));
        colWeekendMultiplier.setCellValueFactory(new PropertyValueFactory<>("weekendMultiplier"));
        
        loadTable();
        tableListener(); 
    }

    private void loadTable() {
        try {
            tblCategory.setItems(FXCollections.observableArrayList(service.getAll()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void tableListener() {
        tblCategory.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                txtId.setText(String.valueOf(newVal.getCategoryId()));
                txtName.setText(newVal.getName());
                txtDescription.setText(newVal.getDescription());
                txtBaseFactor.setText(String.valueOf(newVal.getBasePriceFactor()));
                txtWeekendMultiplier.setText(String.valueOf(newVal.getWeekendMultiplier()));
                txtLateFee.setText(String.valueOf(newVal.getDefaultLateFeePerDay())); 
                chkActive.setSelected(newVal.isActive());
            }
        });
    }

    @FXML
    void btnSave(ActionEvent e) {
        try {
            CategoryDto dto = new CategoryDto(
                    txtName.getText(),
                    txtDescription.getText(),
                    Double.parseDouble(txtBaseFactor.getText()),
                    Double.parseDouble(txtWeekendMultiplier.getText()),
                    Double.parseDouble(txtLateFee.getText()),
                    chkActive.isSelected()
            );

            if (service.save(dto)) {
                new Alert(Alert.AlertType.INFORMATION, "Category Saved!").show();
                loadTable();
                clearFields();
            }
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Save Failed! Check input data.").show();
        }
    }

    @FXML
    void btnUpdate(ActionEvent e) {
        try {
            if (txtId.getText().isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "Please select a Category from the table first!").show();
                return;
            }

            CategoryDto dto = new CategoryDto(
                    Integer.parseInt(txtId.getText()), 
                    txtName.getText(),
                    txtDescription.getText(),
                    Double.parseDouble(txtBaseFactor.getText()),
                    Double.parseDouble(txtWeekendMultiplier.getText()),
                    Double.parseDouble(txtLateFee.getText()),
                    chkActive.isSelected()
            );

            if (service.update(dto)) {
                new Alert(Alert.AlertType.INFORMATION, "Category Updated Successfully!").show();
                loadTable();
                clearFields();
            }
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Update Failed!").show();
        }
    }

    @FXML
    void btnDelete(ActionEvent e) {
        try {
            if (txtId.getText().isEmpty()) {
                new Alert(Alert.AlertType.WARNING, "Select a Category to delete!").show();
                return;
            }

            int id = Integer.parseInt(txtId.getText());
            if (service.delete(id)) {
                new Alert(Alert.AlertType.INFORMATION, "Category Deleted Successfully!").show();
                loadTable();
                clearFields();
            }
        } catch (Exception ex) {
            new Alert(Alert.AlertType.ERROR, "Delete Failed!").show();
        }
    }

    private void clearFields() {
        txtId.clear();
        txtName.clear();
        txtDescription.clear();
        txtBaseFactor.clear();
        txtWeekendMultiplier.clear();
        txtLateFee.clear();
        chkActive.setSelected(false);
    }
}