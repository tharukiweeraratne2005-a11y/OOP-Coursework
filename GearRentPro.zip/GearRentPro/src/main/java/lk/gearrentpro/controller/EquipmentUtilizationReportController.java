/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import lk.gearrentpro.dao.custom.EquipmentUtilizationReportDao;
import lk.gearrentpro.dao.custom.impl.EquipmentUtilizationReportDaoImpl;
import lk.gearrentpro.dto.EquipmentUtilizationReportDto;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javafx.event.ActionEvent;

public class EquipmentUtilizationReportController {
    @FXML private DatePicker dpFrom;
    @FXML private DatePicker dpTo;

    
    @FXML private TableView<EquipmentUtilizationReportDto> tblUtilization; 
    @FXML private TableColumn<EquipmentUtilizationReportDto, String> colCode;
    @FXML private TableColumn<EquipmentUtilizationReportDto, String> colBrand;
    @FXML private TableColumn<EquipmentUtilizationReportDto, String> colModel;
    @FXML private TableColumn<EquipmentUtilizationReportDto, Long> colDaysRented;
    @FXML private TableColumn<EquipmentUtilizationReportDto, Long> colTotalDays;

    private final EquipmentUtilizationReportDao reportDao = new EquipmentUtilizationReportDaoImpl();

    @FXML
    public void initialize() {
        colCode.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getEquipmentCode()));
        colBrand.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getBrand()));
        colModel.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getModel()));
        colDaysRented.setCellValueFactory(data -> new javafx.beans.property.SimpleLongProperty(data.getValue().getDaysRented()).asObject());
        colTotalDays.setCellValueFactory(data -> new javafx.beans.property.SimpleLongProperty(data.getValue().getTotalDays()).asObject());
        
        
    }

    @FXML
    void btnGenerateOnAction(ActionEvent event) {
        LocalDate from = dpFrom.getValue();
        LocalDate to = dpTo.getValue();

        if (from == null || to == null) {
            new Alert(Alert.AlertType.WARNING, "Please select a date range").show();
            return;
        }

        
        try {
            Date startDate = Date.valueOf(from);
            Date endDate = Date.valueOf(to);
           
            List<EquipmentUtilizationReportDto> list = reportDao.getUtilizationReport(startDate, endDate);
            
            if (list == null || list.isEmpty()) {
            new Alert(Alert.AlertType.INFORMATION, "No data found for the selected range").show();
            }
            
            ObservableList<EquipmentUtilizationReportDto> obList = FXCollections.observableArrayList(list);
            tblUtilization.setItems(obList);
            
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error generating report: " + e.getMessage()).show();
            e.printStackTrace();
        }
    }
}