/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import lk.gearrentpro.dto.OverdueRentalDto;
import lk.gearrentpro.service.custom.OverdueRentalService;
import lk.gearrentpro.service.custom.impl.OverdueRentalServiceImpl;

/**
 *
 * @author asus
 */
public class OverdueRentalController {
    @FXML private TableView<OverdueRentalDto> tblOverdue;
    @FXML private TableColumn<OverdueRentalDto, Integer> colId;
    @FXML private TableColumn<OverdueRentalDto, String> colCode;
    @FXML private TableColumn<OverdueRentalDto, Integer> colEquipment;
    @FXML private TableColumn<OverdueRentalDto, Integer> colCustomer;
    @FXML private TableColumn<OverdueRentalDto, Integer> colBranch;
    @FXML private TableColumn<OverdueRentalDto, Integer> colDays;
    @FXML private TableColumn<OverdueRentalDto, Double> colFee;

    private final OverdueRentalService service = new OverdueRentalServiceImpl();

    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("reservationId"));
        colCode.setCellValueFactory(new PropertyValueFactory<>("reservationCode"));
        colEquipment.setCellValueFactory(new PropertyValueFactory<>("equipmentId"));
        colCustomer.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        colBranch.setCellValueFactory(new PropertyValueFactory<>("branchId"));
        colDays.setCellValueFactory(new PropertyValueFactory<>("overdueDays"));
        colFee.setCellValueFactory(new PropertyValueFactory<>("lateFee"));

        loadTable();
    }

    private void loadTable() {
        ObservableList<OverdueRentalDto> list =
                FXCollections.observableArrayList(service.getAllOverdueRentals());
        tblOverdue.setItems(list);
    } 
}
