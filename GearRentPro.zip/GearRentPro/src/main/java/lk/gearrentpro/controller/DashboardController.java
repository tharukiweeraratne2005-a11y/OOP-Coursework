/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;

/**
 * @author asus
 */
public class DashboardController {

    @FXML
    private AnchorPane centerNode; 

    @FXML
    public void initialize() {
        Platform.runLater(() -> {
            navigateTo("/lk/gearrentpro/view/WelcomeForm.fxml"); 
        });
    }

    // --- Navigation Methods ---

    @FXML
    private void btnCustomersOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/CustomerForm.fxml");
    }

    @FXML
    void btnEquipmentsOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/EquipmentForm.fxml");
    }

    @FXML
    void btnRentalsOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/RentalForm.fxml");
    }

    @FXML
    void btnReturnOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/ReturnForm.fxml");
    }

    @FXML
    void btnUsersOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/UserForm.fxml");
    }

    @FXML
    void btnCategoryOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/CategoryForm.fxml");
    }

    @FXML
    void btnReservationOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/ReservationForm.fxml");
    }

    @FXML
    void btnOverdueRentalOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/OverdueRentalForm.fxml");
    }

    @FXML
    void btnReportsOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/ReportsForm.fxml");
    }

    @FXML
    private void btnBranchOnAction(ActionEvent event) {
        navigateTo("/lk/gearrentpro/view/BranchForm.fxml");
    }

    @FXML
    void btnLogoutOnAction(ActionEvent event) {
        try {
            Parent loginRoot = FXMLLoader.load(getClass().getResource("/lk/gearrentpro/view/LoginForm.fxml"));
            centerNode.getScene().setRoot(loginRoot);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void navigateTo(String fxmlPath) {
        try {
            if (centerNode == null) {
                System.err.println("Error: centerNode is null. Please check fx:id in FXML.");
                return;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();

            centerNode.getChildren().clear();
            centerNode.getChildren().add(root);

            AnchorPane.setTopAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 0.0);
            AnchorPane.setRightAnchor(root, 0.0);

        } catch (IOException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Page can't load: " + fxmlPath).show();
        }
    }
}