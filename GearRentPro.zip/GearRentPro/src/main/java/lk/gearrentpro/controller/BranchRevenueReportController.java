/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import lk.gearrentpro.dto.BranchRevenueReportDto;
import lk.gearrentpro.dao.custom.impl.BranchRevenueReportDaoImpl;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import lk.gearrentpro.dao.custom.BranchRevenueReportDao;

/**
 *
 * @author asus
 */
public class BranchRevenueReportController {
    @FXML private DatePicker dpFrom;
    @FXML private DatePicker dpTo;
    @FXML private TableView<BranchRevenueReportDto> tblReport;
    @FXML private TableColumn<BranchRevenueReportDto, String> colBranch;
    @FXML private TableColumn<BranchRevenueReportDto, Integer> colRentals;
    @FXML private TableColumn<BranchRevenueReportDto, Double> colIncome;
    @FXML private TableColumn<BranchRevenueReportDto, Double> colLateFees;
    @FXML private TableColumn<BranchRevenueReportDto, Double> colDamage;

    private final BranchRevenueReportDao reportDao = new BranchRevenueReportDaoImpl();

    @FXML
    void initialize() {
        colBranch.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getBranchName()));
        colRentals.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getTotalRentals()).asObject());
        colIncome.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getTotalIncome()).asObject());
        colLateFees.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getTotalLateFees()).asObject());
        colDamage.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getTotalDamageCharges()).asObject());
    }

    @FXML
    void btnGenerateOnAction() {
        LocalDate fromDate = dpFrom.getValue();
        LocalDate toDate = dpTo.getValue();

        if(fromDate == null || toDate == null) return;

        List<BranchRevenueReportDto> list = reportDao.getRevenueReport(
                java.sql.Date.valueOf(fromDate), java.sql.Date.valueOf(toDate)
        );
        ObservableList<BranchRevenueReportDto> obList = FXCollections.observableArrayList(list);
        tblReport.setItems(obList);
    }
    
}
