/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.controller;

import java.io.IOException;
import java.net.URL;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author asus
 */
public class ReportController {
    
@FXML
private AnchorPane pagingPane;  

@FXML
void btnBranchRevenueReportOnAction(ActionEvent event) throws IOException {
    
    setPage("BranchRevenueReportForm.fxml"); 
}

@FXML
void btnEquipmentUtilizationReportOnAction(ActionEvent event) throws IOException {
    
    setPage("EquipmentUtilizationReportForm.fxml");
}


private void setPage(String fxml) throws IOException {
    URL resource = getClass().getResource("/lk/gearrentpro/view/" + fxml);
    
    if (resource == null) {
        throw new IOException("FXML file not found: " + fxml);
    }

    Parent load = FXMLLoader.load(resource);
    
    
    pagingPane.getChildren().clear(); 
    pagingPane.getChildren().add(load);
    
    AnchorPane.setTopAnchor(load, 0.0);
    AnchorPane.setBottomAnchor(load, 0.0);
    AnchorPane.setLeftAnchor(load, 0.0);
    AnchorPane.setRightAnchor(load, 0.0);
}
    }
    

    

