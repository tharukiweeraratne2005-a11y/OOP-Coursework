/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.entity;

/**
 *
 * @author asus
 */
public class ConfigEntity {
    private String cfgKey;
    private String cfgValue;
    
public ConfigEntity() {
}

public ConfigEntity(String cfgKey, String cfgValue) {
    this.cfgKey = cfgKey;
    this.cfgValue = cfgValue;
}

    /**
     * @return the cfgKey
     */
    public String getCfgKey() {
        return cfgKey;
    }

    /**
     * @param cfgKey the cfgKey to set
     */
    public void setCfgKey(String cfgKey) {
        this.cfgKey = cfgKey;
    }

    /**
     * @return the cfgValue
     */
    public String getCfgValue() {
        return cfgValue;
    }

    /**
     * @param cfgValue the cfgValue to set
     */
    public void setCfgValue(String cfgValue) {
        this.cfgValue = cfgValue;
    }

    @Override
    public String toString() {
        return "ConfigEntity{" + "cfgKey=" + cfgKey + ", cfgValue=" + cfgValue + '}';
    }



    

    
}
