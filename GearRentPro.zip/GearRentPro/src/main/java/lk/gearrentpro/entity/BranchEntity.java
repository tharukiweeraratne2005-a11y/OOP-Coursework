/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.entity;

/**
 *
 * @author asus
 */
public class BranchEntity {
    private int branchId;
    private String code;
    private String name;
    private String address;
    private String contact;
    

    public BranchEntity() {
        
        
    }
    public BranchEntity(String code, String name, String address, String contact) {
        this.code = code;
        this.name = name;
        this.address = address;
        this.contact = contact;
    }

    public BranchEntity(int branchId, String code, String name, String address, String contact) {
        this.branchId = branchId;
        this.code = code;
        this.name = name;
        this.address = address;
        this.contact = contact;
    }
    

    /**
     * @return the branchId
     */
    public int getBranchId() {
        return branchId;
    }

    /**
     * @param branchId the branchId to set
     */
    public void setBranchId(int branchId) {
        this.branchId = branchId;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the contact
     */
    public String getContact() {
        return contact;
    }

    /**
     * @param contact the contact to set
     */
    public void setContact(String contact) {
        this.contact = contact;
    }

    @Override
    public String toString() {
        return "Branch{" + "branchId=" + branchId + ", code=" + code + ", name=" + name + ", address=" + address + ", contact=" + contact + '}';
    }
    
}
