/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.entity;

/**
 *
 * @author asus
 */
public class BranchRevenueEntity {
    private int branchId;
    private String branchName;
    private int totalRentals;
    private double totalIncome;
    private double totalLateFees;
    private double totalDamageCharges;

    public BranchRevenueEntity() {
    }

    public BranchRevenueEntity(int branchId, String branchName, int totalRentals, double totalIncome, double totalLateFees, double totalDamageCharges) {
        this.branchId = branchId;
        this.branchName = branchName;
        this.totalRentals = totalRentals;
        this.totalIncome = totalIncome;
        this.totalLateFees = totalLateFees;
        this.totalDamageCharges = totalDamageCharges;
    }

    /**
     * @return the branchId
     */
    public int getBranchId() {
        return branchId;
    }

    /**
     * @param branchId the branchId to set
     */
    public void setBranchId(int branchId) {
        this.branchId = branchId;
    }

    /**
     * @return the branchName
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * @param branchName the branchName to set
     */
    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    /**
     * @return the totalRentals
     */
    public int getTotalRentals() {
        return totalRentals;
    }

    /**
     * @param totalRentals the totalRentals to set
     */
    public void setTotalRentals(int totalRentals) {
        this.totalRentals = totalRentals;
    }

    /**
     * @return the totalIncome
     */
    public double getTotalIncome() {
        return totalIncome;
    }

    /**
     * @param totalIncome the totalIncome to set
     */
    public void setTotalIncome(double totalIncome) {
        this.totalIncome = totalIncome;
    }

    /**
     * @return the totalLateFees
     */
    public double getTotalLateFees() {
        return totalLateFees;
    }

    /**
     * @param totalLateFees the totalLateFees to set
     */
    public void setTotalLateFees(double totalLateFees) {
        this.totalLateFees = totalLateFees;
    }

    /**
     * @return the totalDamageCharges
     */
    public double getTotalDamageCharges() {
        return totalDamageCharges;
    }

    /**
     * @param totalDamageCharges the totalDamageCharges to set
     */
    public void setTotalDamageCharges(double totalDamageCharges) {
        this.totalDamageCharges = totalDamageCharges;
    }

    @Override
    public String toString() {
        return "BranchRevenueEntity{" + "branchId=" + branchId + ", branchName=" + branchName + ", totalRentals=" + totalRentals + ", totalIncome=" + totalIncome + ", totalLateFees=" + totalLateFees + ", totalDamageCharges=" + totalDamageCharges + '}';
    }

    
    
}
