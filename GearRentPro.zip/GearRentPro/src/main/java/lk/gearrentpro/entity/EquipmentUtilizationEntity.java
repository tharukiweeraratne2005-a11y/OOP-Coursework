/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lk.gearrentpro.entity;

/**
 *
 * @author asus
 */
public class EquipmentUtilizationEntity {
    private int equipmentId;
    private String equipmentCode;
    private String brand;
    private String model;
    private long daysRented;
    private long totalTimes;

public EquipmentUtilizationEntity() {
}

public EquipmentUtilizationEntity(int equipmentId, String equipmentCode, String brand, String model, long daysRented, long totalTimes) {
    this.equipmentId = equipmentId;
    this.equipmentCode = equipmentCode;
    this.brand = brand;
    this.model = model;
    this.daysRented = daysRented;
    this.totalTimes = totalTimes;
    
}

    /**
     * @return the equipmentId
     */
    public int getEquipmentId() {
        return equipmentId;
    }

    /**
     * @param equipmentId the equipmentId to set
     */
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    /**
     * @return the equipmentCode
     */
    public String getEquipmentCode() {
        return equipmentCode;
    }

    /**
     * @param equipmentCode the equipmentCode to set
     */
    public void setEquipmentCode(String equipmentCode) {
        this.equipmentCode = equipmentCode;
    }

    /**
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand the brand to set
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * @return the daysRented
     */
    public long getDaysRented() {
        return daysRented;
    }

    /**
     * @param daysRented the daysRented to set
     */
    public void setDaysRented(long daysRented) {
        this.daysRented = daysRented;
    }

    /**
     * @return the totalTimes
     */
    public long getTotalTimes() {
        return totalTimes;
    }

    /**
     * @param totalTimes the totalTimes to set
     */
    public void setTotalTimes(long totalTimes) {
        this.totalTimes = totalTimes;
    }

    @Override
    public String toString() {
        return "EquipmentUtilizationEntity{" + "equipmentId=" + equipmentId + ", equipmentCode=" + equipmentCode + ", brand=" + brand + ", model=" + model + ", daysRented=" + daysRented + ", totalTimes=" + totalTimes + '}';
    }
    

}
    


    