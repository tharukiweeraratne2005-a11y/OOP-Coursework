-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: gearrentpro
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `branch_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'PAN','Panadura','Panadura main road','+94123456789'),(2,'GAL','Galle','Galle fort','+94111222333'),(3,'KAL','Kalutara','Kalutara central','+94119876543');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_price_factor` decimal(6,3) NOT NULL DEFAULT '1.000',
  `weekend_multiplier` decimal(4,2) NOT NULL DEFAULT '1.00',
  `default_late_fee_per_day` decimal(10,2) DEFAULT '0.00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Camera','Professional DSLR and mirrorless',1.000,1.10,500.00,1),(2,'Lens','Prime and zoom lenses',0.700,1.05,300.00,1),(3,'Drone','Aerial drones',1.500,1.20,1500.00,1),(4,'Lighting','Lighting kits and stands',0.600,1.05,400.00,1),(5,'Audio','Microphones and recorders',0.500,1.05,300.00,1);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `cfg_key` varchar(100) NOT NULL,
  `cfg_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cfg_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('deposit_limit_per_customer','500000'),('max_rental_days','30');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(30) NOT NULL,
  `name` varchar(150) NOT NULL,
  `nic_passport` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `membership` enum('Regular','Silver','Gold') DEFAULT 'Regular',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'CUST001','Nimal Perera','901234567V','0771234567','nimal@example.com','Panadura','Regular'),(2,'CUST002','Saman Silva','891234567V','0779876543','saman@example.com','Galle','Silver'),(3,'CUST003','Kumari Jayasuriya','199012345678','0715554444','kumari@example.com','Colombo','Gold'),(4,'CUST004','Amal Fernando','811234567V','0773332222','amal@example.com','Kalutara','Regular'),(5,'CUST005','Rashmi Perera','871234567V','0719998888','rashmi@example.com','Panadura','Silver'),(6,'CUST006','Dilan Kumar','861234567V','0774441111','dilan@example.com','Galle','Regular'),(7,'CUST007','Maya Silva','841234567V','0711237890','maya@example.com','Colombo','Gold'),(8,'CUST008','Ishara Kumara','801234567V','0772223333','ishara@example.com','Kalutara','Regular'),(9,'CUST009','Sujan Wick','771234567V','0775556666','sujan@example.com','Panadura','Silver'),(10,'CUST010','Teena Lopes','751234567V','0717776666','teena@example.com','Kandy','Regular'),(15,'CUST011','Sunil Shantha','721234567V','0771112223','sunil@example.com','Matara','Gold'),(16,'CUST012','Piumi Hansika','951234567V','0714445556','piumi@example.com','Negombo','Silver'),(17,'CUST013','Ruwan Perera','831234567V','0778889990','ruwan@example.com','Wattala','Regular'),(18,'CUST014','Dilshan Abey','911234567V','0751110000','dilshan@example.com','Kurunegala','Silver'),(19,'CUST015','Nadeesha Dil','881234567V','0772228888','nadee@example.com','Jaffna','Gold'),(20,'CUST016','Kasun Madu','941234567V','0713337777','kasun@example.com','Anuradhapura','Regular'),(21,'CUST017','Sanduni Fonseka','921234567V','0774446666','sandu@example.com','Ratnapura','Silver'),(22,'CUST018','Nuwan Bandara','851234567V','0701115555','nuwan@example.com','Badulla','Regular'),(23,'CUST019','Hirantha Dev','791234567V','0776664444','hiran@example.com','Hambantota','Gold'),(24,'CUST020','Tharushi Perera','961234567V','0710009999','tharushi@example.com','Kegalle','Regular');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `equipment_id` int NOT NULL AUTO_INCREMENT,
  `equipment_code` varchar(30) NOT NULL,
  `category_id` int NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `purchase_year` year DEFAULT NULL,
  `base_daily_price` decimal(10,2) NOT NULL,
  `security_deposit` decimal(12,2) NOT NULL,
  `status` enum('Available','Reserved','Rented','Under Maintenance') NOT NULL DEFAULT 'Available',
  `branch_id` int NOT NULL,
  PRIMARY KEY (`equipment_id`),
  UNIQUE KEY `equipment_code` (`equipment_code`),
  KEY `category_id` (`category_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `equipment_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,'CAM-PAN-001',1,'Canon','R5',2021,10000.00,50000.00,'Available',1),(2,'CAM-PAN-002',1,'Sony','A7IV',2022,9500.00,45000.00,'Available',1),(3,'LNS-PAN-001',2,'Canon','24-70mm',2019,2500.00,15000.00,'Available',1),(4,'DRN-GAL-001',3,'DJI','Mavic 3',2023,15000.00,100000.00,'Available',2),(5,'LTG-PAN-001',4,'Godox','600W Kit',2020,3000.00,20000.00,'Available',1),(6,'AUD-KAL-001',5,'Zoom','H6',2018,1800.00,10000.00,'Available',3),(7,'CAM-GAL-003',1,'Nikon','Z6II',2020,8500.00,40000.00,'Available',2),(8,'LNS-GAL-002',2,'Sigma','85mm',2019,2000.00,12000.00,'Available',2),(9,'DRN-PAN-002',3,'DJI','Air 2S',2022,12000.00,80000.00,'Available',1),(10,'LTG-GAL-002',4,'Aputure','Light Storm',2021,3200.00,22000.00,'Available',2),(11,'AUD-PAN-002',5,'Rode','NTG3',2017,900.00,5000.00,'Available',1),(12,'CAM-KAL-004',1,'Sony','FX3',2022,13000.00,60000.00,'Available',3),(13,'LNS-KAL-003',2,'Tamron','24-70',2020,2200.00,14000.00,'Available',3),(14,'CAM-PAN-005',1,'Blackmagic','Pocket6K',2021,9000.00,45000.00,'Available',1),(15,'DRN-KAL-002',3,'Autel','EVO II',2020,14000.00,90000.00,'Available',3),(16,'AUD-GAL-004',5,'Sennheiser','MKH416',2016,1200.00,8000.00,'Available',2),(17,'LTG-KAL-003',4,'NanLite','Forza',2022,3500.00,23000.00,'Available',3),(18,'LNS-PAN-006',1,'Canon','50mm',2018,1200.00,8000.00,'Available',1),(19,'CAM-GAL-007',1,'Panasonic','S5',2021,8000.00,40000.00,'Available',2),(20,'AUD-PAN-007',5,'Tascam','DR-40X',2019,700.00,5000.00,'Available',1);
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental`
--

DROP TABLE IF EXISTS `rental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental` (
  `rental_id` int NOT NULL AUTO_INCREMENT,
  `rental_code` varchar(40) NOT NULL,
  `equipment_id` int NOT NULL,
  `customer_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `rental_amount` decimal(12,2) NOT NULL,
  `security_deposit` decimal(12,2) NOT NULL,
  `membership_discount_pct` decimal(5,2) DEFAULT '0.00',
  `long_rental_discount_pct` decimal(5,2) DEFAULT '0.00',
  `final_payable_amount` decimal(12,2) NOT NULL,
  `payment_status` enum('Paid','Partially Paid','Unpaid') DEFAULT 'Unpaid',
  `rental_status` enum('Active','Returned','Overdue','Cancelled') DEFAULT 'Active',
  `actual_return_date` date DEFAULT NULL,
  `damage_description` varchar(1000) DEFAULT NULL,
  `damage_charge` decimal(12,2) DEFAULT '0.00',
  `late_fee_total` decimal(12,2) DEFAULT '0.00',
  PRIMARY KEY (`rental_id`),
  UNIQUE KEY `rental_code` (`rental_code`),
  KEY `customer_id` (`customer_id`),
  KEY `branch_id` (`branch_id`),
  KEY `idx_rent_dates` (`equipment_id`,`start_date`,`end_date`),
  CONSTRAINT `rental_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `rental_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `rental_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental`
--

LOCK TABLES `rental` WRITE;
/*!40000 ALTER TABLE `rental` DISABLE KEYS */;
INSERT INTO `rental` VALUES (2,'RENT-0002',9,1,1,'2025-11-05','2025-11-12','2025-12-05 15:18:21',90000.00,80000.00,0.00,0.00,90000.00,'Unpaid','Returned','2025-12-09',NULL,5000.00,1000.00),(4,'RENT-0001',2,3,1,'2025-10-01','2025-10-10','2025-12-29 10:30:22',85500.00,45000.00,5.00,0.00,81225.00,'Paid','Returned','2025-12-17',NULL,8000.00,1000.00);
/*!40000 ALTER TABLE `rental` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental_return`
--

DROP TABLE IF EXISTS `rental_return`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental_return` (
  `return_id` int NOT NULL,
  `rental_id` int DEFAULT NULL,
  `equipment_id` int DEFAULT NULL,
  `customer_id` int DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `damage_charge` double DEFAULT NULL,
  `late_fee` double DEFAULT NULL,
  PRIMARY KEY (`return_id`),
  UNIQUE KEY `rental_id` (`rental_id`),
  CONSTRAINT `rental_return_ibfk_1` FOREIGN KEY (`rental_id`) REFERENCES `rental` (`rental_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental_return`
--

LOCK TABLES `rental_return` WRITE;
/*!40000 ALTER TABLE `rental_return` DISABLE KEYS */;
INSERT INTO `rental_return` VALUES (1,4,5,10,'2025-12-25',500,150),(2,2,3,8,'2025-12-17',800,100);
/*!40000 ALTER TABLE `rental_return` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `reservation_code` varchar(40) NOT NULL,
  `equipment_id` int NOT NULL,
  `customer_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Active','Cancelled','Converted') DEFAULT 'Active',
  PRIMARY KEY (`reservation_id`),
  UNIQUE KEY `reservation_code` (`reservation_code`),
  KEY `customer_id` (`customer_id`),
  KEY `branch_id` (`branch_id`),
  KEY `idx_eq_dates` (`equipment_id`,`start_date`,`end_date`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`equipment_id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (1,'RES-0001',1,2,1,'2025-11-01','2025-11-05','2025-12-05 15:17:38','Active'),(2,'RES-0002',4,3,2,'2025-10-20','2025-10-27','2025-12-05 15:17:38','Active'),(5,'RES-0003',5,8,1,'2025-11-04','2025-12-31','2025-12-30 11:23:42','Cancelled');
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `role` enum('Admin','BranchManager','Staff') DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_user_branch` (`branch_id`),
  CONSTRAINT `fk_user_branch` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','Admin@123','Admin',NULL,'System Administrator'),(2,'manager_pan','Manager@123','BranchManager',1,'Pan Branch Manager'),(3,'staff_pan','Staff@123','Staff',1,'Pan Branch Staff');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-30 14:23:40
